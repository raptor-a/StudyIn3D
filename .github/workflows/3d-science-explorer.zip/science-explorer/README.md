# 3D Science Explorer — Class 10

An interactive 3D web app for exploring the Class 10 Physics, Chemistry and Biology
syllabus. No quizzes, no flashcards, no login — just a 3D viewer, a syllabus-wide
navigation tree, and search.

## Running it

```
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

> This project was generated in a sandbox with no network access, so `npm install`
> has **not** been run or tested here. The code is written carefully against the
> pinned dependency versions in `package.json`, but if you hit an install or runtime
> error, paste it back and it can be fixed directly.

## What's actually built

**22 fully interactive 3D models** span all 16 chapters across the three subjects —
every chapter has at least one real, rotatable model, not a placeholder:

- **Physics (8):** spherical mirrors (concave/convex), convex/concave lenses, prism
  dispersion, the human eye, an electric circuit (series/parallel), an electric motor,
  a bar magnet's field lines, a solar panel.
- **Chemistry (7):** the combination reaction that forms water, the pH scale, a
  sodium chloride ionic lattice, methane, ethanol, ethene, and a periodic table
  explorer (first 20 elements, each opening a Bohr atomic model).
- **Biology (7):** the human heart (with animated blood flow), a nephron, the
  digestive system, a neuron, a reproductive system overview, a DNA double helix,
  and a food-chain energy pyramid.

The full syllabus from the brief — all ~150 individual diagrams it lists — is **not**
all built; that's realistically weeks of work, not one pass. What *is* done: every
chapter's full topic list is in the navigation data (`src/data/chapters.ts`) as a
roadmap, so topics without a 3D model yet show a clean "coming soon" state instead of
a broken link, and the architecture is built so new models drop in easily (see below).

## Architecture

```
src/
  data/               Plain data: subjects, chapters, syllabus roadmap, model
                       metadata (title, description, components, learning points).
                       No rendering code lives here.
  components/
    models/
      shared/          Reusable 3D building blocks: LabelMarker, TubePath,
                       Molecule3D (atoms + bonds), AtomModel (Bohr model), ModelHud
                       (in-scene toggle buttons).
      physics/
      chemistry/       One file per model — the actual Three.js/R3F geometry.
      biology/
      registry.tsx     Maps each model id to its component, lazily imported so a
                       model's geometry only loads when it's opened.
    viewer/            The reusable <Viewer3D> canvas (orbit controls, reset,
                       auto-rotate, label toggle, fullscreen) + loading/placeholder
                       states.
    layout/            Sidebar, top bar + search, info panel.
    home/              Landing page.
  pages/ExplorerPage.tsx   Wires sidebar + viewer + info panel together.
  App.tsx              Switches between the home page and the explorer.
```

## Adding a new model

1. Add a `ScienceModel` entry to the right file in `src/data/models/` (title,
   description, `components` — the labelled parts — and `learningPoints`).
2. Add its id to the matching chapter's `modelIds` in `src/data/chapters.ts` (and
   remove it from that chapter's `comingSoonTopics` if it was listed there).
3. Create the component in `src/components/models/<subject>/`. It receives
   `{ showLabels, selectedComponent, onSelectComponent }` and renders a `<group>` of
   Three.js meshes — reuse `TubePath`/`Molecule3D`/`LabelMarker` from `shared/` where
   they fit rather than starting from scratch.
4. Register it in `src/components/models/registry.tsx`:
   `'your-model-id': lazy(() => import('./<subject>/YourModel'))`.

That's the whole loop — the sidebar, search, home page stats and info panel all read
from the data layer automatically.

## Deploying to GitHub Pages

This repo is set up to deploy automatically to `https://raptor-a.github.io/StudyIn3D/`:

1. In the repo on GitHub: **Settings → Pages → Build and deployment → Source** →
   change it to **GitHub Actions** (it can't default to this — it has to be set
   once by hand).
2. Push to `main`. `.github/workflows/deploy.yml` builds the app with
   `npm run build` and deploys the `dist/` output — not the raw source — which is
   what GitHub Pages actually needs; raw `.tsx` files can't run in a browser
   unbuilt, which is why a direct upload of this folder shows a blank page.
3. If the repo is ever renamed, update `base` in `vite.config.ts` to match
   (`'/<new-repo-name>/'`), since GitHub Pages serves a project site from that
   subpath.

## Stack

React 18 + TypeScript + Vite + Three.js + React Three Fiber + Drei + Tailwind CSS +
lucide-react icons. No backend; "recently viewed" is stored in the browser's
`localStorage`.
