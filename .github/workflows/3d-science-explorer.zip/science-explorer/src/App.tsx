import { useState } from 'react';
import HomePage from './components/home/HomePage';
import ExplorerPage from './pages/ExplorerPage';
import { chaptersForSubject, modelsForChapter, getModelById } from './data';
import type { Subject } from './types';
import type { SearchResult } from './data';

interface ExplorerEntry {
  subject: Subject;
  chapterId: string;
  modelId: string | null;
  comingSoonTopic?: string;
}

export default function App() {
  const [entry, setEntry] = useState<ExplorerEntry | null>(null);

  function openSubject(subject: Subject) {
    const firstChapter = chaptersForSubject(subject)[0];
    const firstModel = firstChapter ? modelsForChapter(firstChapter.id)[0] : undefined;
    setEntry({ subject, chapterId: firstChapter?.id ?? '', modelId: firstModel?.id ?? null });
  }

  function openModel(modelId: string) {
    const model = getModelById(modelId);
    if (!model) return;
    setEntry({ subject: model.subject, chapterId: model.chapterId, modelId });
  }

  function openSearchResult(result: SearchResult) {
    if (result.type === 'model' && result.modelId) {
      openModel(result.modelId);
    } else {
      setEntry({ subject: result.subject, chapterId: result.chapterId, modelId: null, comingSoonTopic: result.title });
    }
  }

  if (!entry) {
    return (
      <div className="h-screen overflow-y-auto bg-paper">
        <HomePage onSelectSubject={openSubject} onSearchSelect={openSearchResult} onSelectModel={openModel} />
      </div>
    );
  }

  return (
    <div className="h-screen overflow-hidden bg-paper">
      <ExplorerPage
        key={`${entry.subject}-${entry.chapterId}-${entry.modelId ?? entry.comingSoonTopic ?? 'none'}`}
        initialSubject={entry.subject}
        initialChapterId={entry.chapterId}
        initialModelId={entry.modelId}
        initialComingSoonTopic={entry.comingSoonTopic}
        onGoHome={() => setEntry(null)}
      />
    </div>
  );
}
