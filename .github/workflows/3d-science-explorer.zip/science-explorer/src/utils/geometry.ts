export type Pt3 = [number, number, number];

/** Points along a helix, for coiled tubules (nephron), DNA backbones, springs. */
export function helixPoints(opts: {
  turns: number;
  radius: number;
  height: number;
  pointsPerTurn?: number;
  center?: Pt3;
  phase?: number;
}): Pt3[] {
  const { turns, radius, height, pointsPerTurn = 14, center = [0, 0, 0], phase = 0 } = opts;
  const total = Math.round(turns * pointsPerTurn);
  const pts: Pt3[] = [];
  for (let i = 0; i <= total; i++) {
    const t = (i / pointsPerTurn) * Math.PI * 2 + phase;
    const y = (i / total) * height;
    pts.push([center[0] + Math.cos(t) * radius, center[1] + y, center[2] + Math.sin(t) * radius]);
  }
  return pts;
}

/** Smooth-ish catmull points through hand-specified control points — just returns them as-is,
 *  kept as a named helper so model files read clearly. */
export function path(...points: Pt3[]): Pt3[] {
  return points;
}
