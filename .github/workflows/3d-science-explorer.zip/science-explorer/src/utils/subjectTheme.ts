import type { Subject } from '../types';

// Tailwind's scanner needs full, literal class strings (not template-built ones),
// so every class used anywhere in the app is spelled out here once and reused.
export const subjectTheme: Record<
  Subject,
  { text: string; activeChip: string; dot: string; softBg: string; solidBg: string; ring: string }
> = {
  physics: {
    text: 'text-physics',
    activeChip: 'bg-physics-soft text-physics-deep',
    dot: 'bg-physics',
    softBg: 'bg-physics-soft',
    solidBg: 'bg-physics',
    ring: 'ring-physics',
  },
  chemistry: {
    text: 'text-chemistry',
    activeChip: 'bg-chemistry-soft text-chemistry-deep',
    dot: 'bg-chemistry',
    softBg: 'bg-chemistry-soft',
    solidBg: 'bg-chemistry',
    ring: 'ring-chemistry',
  },
  biology: {
    text: 'text-biology',
    activeChip: 'bg-biology-soft text-biology-deep',
    dot: 'bg-biology',
    softBg: 'bg-biology-soft',
    solidBg: 'bg-biology',
    ring: 'ring-biology',
  },
};
