import { useEffect, useState } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // storage unavailable (private browsing, quota) — fail silently
    }
  }, [key, value]);

  return [value, setValue] as const;
}

export function useRecentlyViewed(max = 6) {
  const [ids, setIds] = useLocalStorage<string[]>('sciex:recently-viewed', []);

  function record(id: string) {
    setIds((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, max));
  }

  return { recentIds: ids, record };
}
