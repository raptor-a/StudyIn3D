import { X } from 'lucide-react';
import { chapters, subjectMeta, modelsForChapter } from '../../data';
import { subjectTheme } from '../../utils/subjectTheme';
import type { Subject } from '../../types';

interface Props {
  activeSubject: Subject | null;
  activeChapterId: string | null;
  activeModelId: string | null;
  onSelectChapter: (chapterId: string) => void;
  onSelectModel: (modelId: string) => void;
  onSelectComingSoon: (chapterId: string, topic: string) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const subjectOrder: Subject[] = ['physics', 'chemistry', 'biology'];

function SubjectSection({
  subject,
  activeChapterId,
  activeModelId,
  onSelectChapter,
  onSelectModel,
  onSelectComingSoon,
}: Omit<Props, 'mobileOpen' | 'onCloseMobile' | 'activeSubject'> & { subject: Subject }) {
  const subjectChapters = chapters.filter((c) => c.subject === subject);
  const theme = subjectTheme[subject];

  return (
    <div className="mb-5">
      <p className={`mb-1.5 px-3 font-display text-[13px] font-semibold ${theme.text}`}>{subjectMeta[subject].title}</p>
      <div className="space-y-0.5">
        {subjectChapters.map((chapter) => {
          const isExpanded = chapter.id === activeChapterId;
          const models = modelsForChapter(chapter.id);
          return (
            <div key={chapter.id}>
              <button
                type="button"
                onClick={() => onSelectChapter(chapter.id)}
                className={`w-full rounded px-3 py-1.5 text-left font-body text-[13px] transition-colors ${
                  isExpanded ? 'bg-paper font-medium text-ink' : 'text-ink-soft hover:bg-paper/70 hover:text-ink'
                }`}
              >
                {chapter.title}
              </button>
              {isExpanded && (
                <div className="ml-3 mb-1.5 mt-0.5 space-y-0.5 border-l border-line pl-3">
                  {models.map((model) => (
                    <button
                      key={model.id}
                      type="button"
                      onClick={() => onSelectModel(model.id)}
                      className={`block w-full truncate rounded px-2 py-1 text-left font-body text-[12.5px] transition-colors ${
                        activeModelId === model.id ? `${theme.activeChip} font-medium` : 'text-ink-soft hover:text-ink'
                      }`}
                    >
                      {model.title}
                    </button>
                  ))}
                  {chapter.comingSoonTopics.map((topic) => (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => onSelectComingSoon(chapter.id, topic)}
                      className="flex w-full items-center justify-between truncate rounded px-2 py-1 text-left font-body text-[12.5px] text-ink-soft/50 hover:text-ink-soft"
                    >
                      <span className="truncate">{topic}</span>
                      <span className="ml-1.5 shrink-0 text-[9.5px]">soon</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function Sidebar({
  activeChapterId,
  activeModelId,
  onSelectChapter,
  onSelectModel,
  onSelectComingSoon,
  mobileOpen,
  onCloseMobile,
}: Props) {
  const content = (
    <div className="h-full overflow-y-auto px-2 py-4">
      {subjectOrder.map((subject) => (
        <SubjectSection
          key={subject}
          subject={subject}
          activeChapterId={activeChapterId}
          activeModelId={activeModelId}
          onSelectChapter={onSelectChapter}
          onSelectModel={onSelectModel}
          onSelectComingSoon={onSelectComingSoon}
        />
      ))}
    </div>
  );

  return (
    <>
      <aside className="hidden h-full w-64 shrink-0 border-r border-line bg-white md:block">{content}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={onCloseMobile} />
          <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-line px-3 py-3">
              <span className="font-display text-sm font-semibold">Chapters</span>
              <button type="button" onClick={onCloseMobile} className="rounded p-1 text-ink-soft hover:bg-paper" aria-label="Close menu">
                <X size={18} />
              </button>
            </div>
            <div className="h-[calc(100%-49px)] overflow-y-auto">{content}</div>
          </div>
        </div>
      )}
    </>
  );
}
