import type { ScienceModel, Chapter } from '../../types';

interface ContentProps {
  model: ScienceModel | null;
  chapter: Chapter | null;
  comingSoonLabel: string | null;
  selectedComponent: string | null;
  onSelectComponent: (id: string | null) => void;
  compact?: boolean;
}

function PanelContent({ model, chapter, comingSoonLabel, selectedComponent, onSelectComponent, compact }: ContentProps) {
  if (!model) {
    return (
      <div>
        {!compact && (
          <p className="font-display text-base font-semibold text-ink">{comingSoonLabel ?? chapter?.title ?? 'Pick a chapter'}</p>
        )}
        {comingSoonLabel && (
          <p className="mt-2 font-body text-[13px] leading-relaxed text-ink-soft">
            An interactive 3D model for this topic isn\u2019t built yet — it\u2019s on the roadmap. Try one of the available models in{' '}
            {chapter?.title ?? 'this chapter'} in the meantime.
          </p>
        )}
        {chapter && (
          <div className="mt-4">
            <p className="font-body text-[12px] font-medium text-ink-soft">About this chapter</p>
            <p className="mt-1 font-body text-[13px] leading-relaxed text-ink-soft">{chapter.blurb}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      {!compact && (
        <>
          <p className="font-display text-lg font-semibold leading-snug text-ink">{model.title}</p>
          <p className="mt-2 font-body text-[13px] leading-relaxed text-ink-soft">{model.description}</p>
        </>
      )}

      {model.components.length > 0 && (
        <div className="mt-4">
          <p className="font-body text-[12px] font-medium text-ink-soft">Parts — tap to explore</p>
          <div className="mt-1.5 space-y-1">
            {model.components.map((c) => {
              const isActive = selectedComponent === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onSelectComponent(isActive ? null : c.id)}
                  className={`block w-full rounded-md border px-2.5 py-1.5 text-left transition-colors ${
                    isActive ? 'border-ink bg-paper' : 'border-transparent hover:bg-paper'
                  }`}
                >
                  <span className="font-body text-[13px] font-medium text-ink">{c.name}</span>
                  {isActive && <span className="mt-0.5 block font-body text-[12px] leading-snug text-ink-soft">{c.description}</span>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {model.learningPoints.length > 0 && (
        <div className="mt-5">
          <p className="font-body text-[12px] font-medium text-ink-soft">Worth noticing</p>
          <ul className="mt-1.5 space-y-1.5">
            {model.learningPoints.map((point, i) => (
              <li key={i} className="font-body text-[13px] leading-relaxed text-ink-soft">
                {point}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

interface Props extends ContentProps {
  expanded: boolean;
  onToggleExpanded: () => void;
}

export default function InfoPanel({ expanded, onToggleExpanded, ...content }: Props) {
  return (
    <>
      <aside className="hidden h-full w-80 shrink-0 overflow-y-auto border-l border-line bg-white px-5 py-5 lg:block">
        <PanelContent {...content} />
      </aside>

      <div
        className={`fixed inset-x-0 bottom-0 z-30 rounded-t-lg border-t border-line bg-white shadow-[0_-4px_16px_rgba(0,0,0,0.12)] transition-[max-height] duration-200 lg:hidden ${
          expanded ? 'max-h-[65vh]' : 'max-h-[58px]'
        }`}
      >
        <button type="button" onClick={onToggleExpanded} className="flex w-full items-center justify-between px-4 py-3.5">
          <span className="truncate pr-3 font-display text-[14px] font-semibold text-ink">
            {content.model?.title ?? content.comingSoonLabel ?? content.chapter?.title ?? 'Select a model'}
          </span>
          <span className="shrink-0 text-ink-soft">{expanded ? '\u2304' : '\u2303'}</span>
        </button>
        {expanded && (
          <div className="max-h-[calc(65vh-54px)] overflow-y-auto px-4 pb-6">
            <PanelContent {...content} compact />
          </div>
        )}
      </div>
    </>
  );
}
