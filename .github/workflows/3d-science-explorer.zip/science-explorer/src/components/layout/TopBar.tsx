import { useState } from 'react';
import { Menu, Search, X } from 'lucide-react';
import { searchAll, type SearchResult } from '../../data';

interface Props {
  onGoHome: () => void;
  onOpenMobileSidebar: () => void;
  breadcrumb: string[];
  onSearchSelect: (result: SearchResult) => void;
}

export default function TopBar({ onGoHome, onOpenMobileSidebar, breadcrumb, onSearchSelect }: Props) {
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);
  const results = searchAll(query);

  return (
    <header className="relative z-30 border-b border-line bg-white">
      <div className="flex items-center gap-2 px-3 py-2.5 md:px-4">
        <button
          type="button"
          onClick={onOpenMobileSidebar}
          className="rounded p-1.5 text-ink-soft hover:bg-paper md:hidden"
          aria-label="Open chapters"
        >
          <Menu size={19} />
        </button>
        <button type="button" onClick={onGoHome} className="shrink-0 font-display text-[15px] font-semibold text-ink">
          3D Science Explorer
        </button>

        <div className="relative ml-auto w-full max-w-[280px]">
          <Search size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-soft/60" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setTimeout(() => setFocused(false), 120)}
            placeholder="Search models…"
            className="w-full rounded-full border border-line bg-paper py-1.5 pl-8 pr-7 font-body text-[13px] text-ink placeholder:text-ink-soft/60 focus:border-ink/40 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-ink-soft/60"
              aria-label="Clear search"
            >
              <X size={13} />
            </button>
          )}
          {focused && query.trim().length >= 2 && (
            <div className="absolute right-0 top-full z-40 mt-1.5 max-h-80 w-80 max-w-[90vw] overflow-y-auto rounded-lg border border-line bg-white py-1.5 shadow-lg">
              {results.length === 0 && <p className="px-3 py-2 font-body text-[12.5px] text-ink-soft">No matches.</p>}
              {results.map((r, i) => (
                <button
                  key={i}
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    onSearchSelect(r);
                    setQuery('');
                  }}
                  className="flex w-full flex-col items-start gap-0.5 px-3 py-1.5 text-left hover:bg-paper"
                >
                  <span className="font-body text-[13px] text-ink">{r.title}</span>
                  <span className="font-body text-[11px] text-ink-soft">
                    {r.chapterTitle}
                    {r.type === 'coming-soon' ? ' · coming soon' : ''}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {breadcrumb.length > 0 && (
        <div className="hidden truncate px-4 pb-2 font-body text-[11.5px] text-ink-soft md:block">{breadcrumb.join(' / ')}</div>
      )}
    </header>
  );
}
