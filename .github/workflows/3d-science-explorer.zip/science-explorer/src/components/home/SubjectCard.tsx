import { subjectTheme } from '../../utils/subjectTheme';
import { subjectMeta } from '../../data';
import type { Subject } from '../../types';

interface Props {
  subject: Subject;
  chapterCount: number;
  modelCount: number;
  onClick: () => void;
}

const descriptors: Record<Subject, string> = {
  physics: 'Mirrors, lenses, circuits, motors and energy systems.',
  chemistry: 'Atoms, molecules, reactions and the periodic table.',
  biology: 'Organs, cells, DNA and the systems that keep you alive.',
};

export default function SubjectCard({ subject, chapterCount, modelCount, onClick }: Props) {
  const theme = subjectTheme[subject];
  return (
    <button
      type="button"
      onClick={onClick}
      className={`group flex flex-col items-start rounded-lg ${theme.softBg} p-5 text-left transition-transform hover:-translate-y-0.5`}
    >
      <span className={`h-2 w-2 rounded-full ${theme.dot}`} />
      <span className="mt-3 font-display text-xl font-semibold text-ink">{subjectMeta[subject].title}</span>
      <span className="mt-1.5 font-body text-[13px] leading-relaxed text-ink-soft">{descriptors[subject]}</span>
      <div className="mt-4 flex gap-2">
        <span className="rounded-full bg-white/70 px-2.5 py-0.5 font-body text-[11.5px] text-ink-soft">{chapterCount} chapters</span>
        <span className="rounded-full bg-white/70 px-2.5 py-0.5 font-body text-[11.5px] text-ink-soft">{modelCount} models</span>
      </div>
    </button>
  );
}
