import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { chaptersForSubject, totalChapterCount, totalModelCount, searchAll, allModels, type SearchResult } from '../../data';
import { useRecentlyViewed } from '../../hooks/useLocalStorage';
import SubjectCard from './SubjectCard';
import type { Subject } from '../../types';

interface Props {
  onSelectSubject: (subject: Subject) => void;
  onSearchSelect: (result: SearchResult) => void;
  onSelectModel: (modelId: string) => void;
}

const subjects: Subject[] = ['physics', 'chemistry', 'biology'];

export default function HomePage({ onSelectSubject, onSearchSelect, onSelectModel }: Props) {
  const [query, setQuery] = useState('');
  const results = searchAll(query);
  const { recentIds } = useRecentlyViewed();
  const recentModels = useMemo(
    () => recentIds.map((id) => allModels.find((m) => m.id === id)).filter((m): m is (typeof allModels)[number] => !!m),
    [recentIds]
  );

  return (
    <div className="mx-auto max-w-5xl px-5 py-10 md:py-16">
      <p className="font-display text-[13px] font-medium text-ink-soft">Class 10 Science</p>
      <h1 className="mt-1 font-display text-4xl font-semibold leading-tight text-ink md:text-[52px]">3D Science Explorer</h1>
      <p className="mt-3 max-w-xl font-body text-[15px] leading-relaxed text-ink-soft">
        Explore Class 10 Physics, Chemistry &amp; Biology in interactive 3D — rotate, zoom and take apart the diagrams your textbook can only draw flat.
      </p>

      <div className="relative mt-7 max-w-md">
        <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-soft/60" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search — human eye, DNA, electric motor…"
          className="w-full rounded-full border border-line bg-white py-2.5 pl-10 pr-4 font-body text-[14px] text-ink shadow-sm placeholder:text-ink-soft/55 focus:border-ink/40 focus:outline-none"
        />
        {query.trim().length >= 2 && (
          <div className="absolute left-0 right-0 top-full z-20 mt-1.5 max-h-72 overflow-y-auto rounded-lg border border-line bg-white py-1.5 shadow-lg">
            {results.length === 0 && <p className="px-3.5 py-2 font-body text-[13px] text-ink-soft">No matches.</p>}
            {results.map((r, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  onSearchSelect(r);
                  setQuery('');
                }}
                className="flex w-full flex-col items-start gap-0.5 px-3.5 py-2 text-left hover:bg-paper"
              >
                <span className="font-body text-[13.5px] text-ink">{r.title}</span>
                <span className="font-body text-[11.5px] text-ink-soft">
                  {r.chapterTitle}
                  {r.type === 'coming-soon' ? ' · coming soon' : ''}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="mt-6 flex gap-2.5">
        <span className="rounded-full border border-line bg-white px-3 py-1 font-body text-[12px] text-ink-soft">{totalChapterCount} chapters</span>
        <span className="rounded-full border border-line bg-white px-3 py-1 font-body text-[12px] text-ink-soft">{totalModelCount} interactive models</span>
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {subjects.map((subject) => (
          <SubjectCard
            key={subject}
            subject={subject}
            chapterCount={chaptersForSubject(subject).length}
            modelCount={chaptersForSubject(subject).reduce((sum, c) => sum + c.modelIds.length, 0)}
            onClick={() => onSelectSubject(subject)}
          />
        ))}
      </div>

      {recentModels.length > 0 && (
        <div className="mt-12">
          <p className="font-body text-[13px] font-medium text-ink-soft">Recently viewed</p>
          <div className="mt-2.5 flex flex-wrap gap-2">
            {recentModels.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => onSelectModel(m.id)}
                className="rounded-full border border-line bg-white px-3.5 py-1.5 font-body text-[13px] text-ink hover:border-ink/30"
              >
                {m.title}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
