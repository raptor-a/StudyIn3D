import { lazy } from 'react';
import type { ComponentType } from 'react';
import type { ModelViewProps } from '../../types';

type LazyModel = ReturnType<typeof lazy<ComponentType<ModelViewProps>>>;

export const modelRegistry: Record<string, LazyModel> = {
  // Physics
  'spherical-mirrors': lazy(() => import('./physics/SphericalMirrors')),
  lenses: lazy(() => import('./physics/Lenses')),
  'prism-dispersion': lazy(() => import('./physics/PrismDispersion')),
  'human-eye': lazy(() => import('./physics/HumanEye')),
  'electric-circuit': lazy(() => import('./physics/ElectricCircuit')),
  'electric-motor': lazy(() => import('./physics/ElectricMotor')),
  'bar-magnet-field-lines': lazy(() => import('./physics/BarMagnetFieldLines')),
  'solar-panel': lazy(() => import('./physics/SolarPanel')),
  // Chemistry
  'water-formation-reaction': lazy(() => import('./chemistry/WaterFormationReaction')),
  'ph-scale': lazy(() => import('./chemistry/PhScale')),
  'ionic-lattice-nacl': lazy(() => import('./chemistry/IonicLattice')),
  methane: lazy(() => import('./chemistry/Methane')),
  ethanol: lazy(() => import('./chemistry/Ethanol')),
  ethene: lazy(() => import('./chemistry/Ethene')),
  'periodic-table-explorer': lazy(() => import('./chemistry/PeriodicTableExplorer')),
  // Biology
  'human-heart': lazy(() => import('./biology/HumanHeart')),
  nephron: lazy(() => import('./biology/Nephron')),
  'digestive-system': lazy(() => import('./biology/DigestiveSystem')),
  neuron: lazy(() => import('./biology/Neuron')),
  'reproductive-system-overview': lazy(() => import('./biology/ReproductiveSystemOverview')),
  'dna-helix': lazy(() => import('./biology/DnaHelix')),
  'food-chain-pyramid': lazy(() => import('./biology/FoodChainPyramid')),
};
