import { useMemo } from 'react';
import * as THREE from 'three';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';
import type { Pt3 } from '../../../utils/geometry';

function Branch({ from, to, radius = 0.028, color = '#C9A46B' }: { from: Pt3; to: Pt3; radius?: number; color?: string }) {
  const { mid, length, quaternion } = useMemo(() => {
    const a = new THREE.Vector3(from[0], from[1], from[2]);
    const b = new THREE.Vector3(to[0], to[1], to[2]);
    const mid = a.clone().add(b).multiplyScalar(0.5);
    const dir = b.clone().sub(a);
    const length = dir.length();
    const quaternion = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    return { mid: [mid.x, mid.y, mid.z] as Pt3, length, quaternion };
  }, [from, to]);

  return (
    <group position={mid} quaternion={quaternion}>
      <mesh>
        <cylinderGeometry args={[radius * 0.4, radius, length, 8]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
    </group>
  );
}

const dendriteTips: Pt3[] = [
  [-0.8, 0.25, 0],
  [-0.75, -0.35, 0.25],
  [-0.7, 0.1, -0.35],
  [-0.6, 0.5, 0.25],
  [-0.65, -0.45, -0.25],
  [-0.85, 0, 0.4],
];

const myelinX = [0.62, 0.98, 1.34, 1.7, 2.06];

const nerveEndingTips: Pt3[] = [
  [2.6, 0.18, 0.1],
  [2.65, -0.1, 0.18],
  [2.58, 0.02, -0.2],
];

export default function Neuron({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <group onClick={pick('dendrites')}>
        {dendriteTips.map((tip, i) => (
          <Branch key={i} from={[tip[0] * 0.35, tip[1] * 0.35, tip[2] * 0.35]} to={tip} />
        ))}
      </group>
      {showLabels && (
        <LabelMarker position={[-0.95, 0.4, 0]} label="Dendrites" active={sel('dendrites')} onClick={() => onSelectComponent('dendrites')} />
      )}

      <mesh onClick={pick('cell-body')}>
        <sphereGeometry args={[0.3, 28, 28]} />
        <meshStandardMaterial color="#D4A72C" roughness={0.45} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, 0.42, 0]} label="Cell Body" active={sel('cell-body')} onClick={() => onSelectComponent('cell-body')} />
      )}

      <mesh position={[1.3, 0, 0]} rotation={[0, 0, Math.PI / 2]} onClick={pick('axon')}>
        <cylinderGeometry args={[0.055, 0.055, 2.0, 16]} />
        <meshStandardMaterial color="#E8D5A0" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[1.3, 0.3, 0]} label="Axon" active={sel('axon')} onClick={() => onSelectComponent('axon')} />}

      <group onClick={pick('myelin')}>
        {myelinX.map((x, i) => (
          <mesh key={i} position={[x, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
            <torusGeometry args={[0.095, 0.038, 10, 20]} />
            <meshStandardMaterial color="#FDF0C8" roughness={0.4} />
          </mesh>
        ))}
      </group>
      {showLabels && (
        <LabelMarker position={[1.3, -0.35, 0]} label="Myelin Sheath" active={sel('myelin')} onClick={() => onSelectComponent('myelin')} />
      )}

      <group onClick={pick('nerve-ending')}>
        {nerveEndingTips.map((tip, i) => (
          <Branch key={i} from={[2.3, 0, 0]} to={tip} radius={0.022} color="#E8D5A0" />
        ))}
      </group>
      {showLabels && (
        <LabelMarker position={[2.7, 0.35, 0]} label="Nerve Ending" active={sel('nerve-ending')} onClick={() => onSelectComponent('nerve-ending')} />
      )}
    </group>
  );
}
