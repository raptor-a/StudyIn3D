import * as THREE from 'three';
import TubePath from '../shared/TubePath';
import LabelMarker from '../shared/LabelMarker';
import { helixPoints, path } from '../../../utils/geometry';
import type { ModelViewProps } from '../../../types';

const pct = helixPoints({ turns: 2.2, radius: 0.22, height: -0.85, center: [0.15, 1.3, 0] });
const loop = path(
  [0.3, 0.45, 0],
  [0.25, -0.3, 0],
  [0.5, -0.55, 0],
  [0.85, -0.55, 0],
  [1.05, -0.3, 0],
  [0.95, 0.45, 0]
);
const dct = helixPoints({ turns: 1.6, radius: 0.2, height: 0.75, center: [0.95, 0.45, 0] });
const collectingDuct = path([1.15, 1.2, 0], [1.4, 0.3, 0], [1.5, -0.6, 0], [1.5, -1.15, 0]);

export default function Nephron({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh position={[0, 1.6, 0]} onClick={pick('bowmans-capsule')}>
        <sphereGeometry args={[0.38, 28, 28]} />
        <meshStandardMaterial color="#F3EFE3" transparent opacity={0.28} side={THREE.DoubleSide} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, 2.05, 0]} label="Bowman's Capsule" active={sel('bowmans-capsule')} onClick={() => onSelectComponent('bowmans-capsule')} />
      )}

      <mesh position={[0, 1.6, 0]} scale={0.5} onClick={pick('glomerulus')}>
        <torusKnotGeometry args={[0.18, 0.045, 64, 8]} />
        <meshStandardMaterial color="#D13B3B" roughness={0.4} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0.35, 1.6, 0]} label="Glomerulus" active={sel('glomerulus')} onClick={() => onSelectComponent('glomerulus')} />
      )}

      <group onClick={pick('pct')}>
        <TubePath points={pct} radius={0.055} color="#C98A2E" />
      </group>
      {showLabels && <LabelMarker position={[0.35, 1.25, 0]} label="Proximal Tubule" active={sel('pct')} onClick={() => onSelectComponent('pct')} />}

      <group onClick={pick('loop-of-henle')}>
        <TubePath points={loop} radius={0.05} color="#2D7DD2" />
      </group>
      {showLabels && (
        <LabelMarker position={[0.67, -0.75, 0]} label="Loop of Henle" active={sel('loop-of-henle')} onClick={() => onSelectComponent('loop-of-henle')} />
      )}

      <group onClick={pick('dct')}>
        <TubePath points={dct} radius={0.055} color="#2E9E5B" />
      </group>
      {showLabels && <LabelMarker position={[1.2, 1.0, 0]} label="Distal Tubule" active={sel('dct')} onClick={() => onSelectComponent('dct')} />}

      <group onClick={pick('collecting-duct')}>
        <TubePath points={collectingDuct} radius={0.065} color="#8B95A5" />
      </group>
      {showLabels && (
        <LabelMarker position={[1.6, -1.2, 0]} label="Collecting Duct" active={sel('collecting-duct')} onClick={() => onSelectComponent('collecting-duct')} />
      )}
    </group>
  );
}
