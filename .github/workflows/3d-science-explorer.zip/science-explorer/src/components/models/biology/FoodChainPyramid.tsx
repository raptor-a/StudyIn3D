import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const tiers = [
  { id: 'producers', y: -0.9, size: 2.4, color: '#3F8F4F', label: 'Grass — Producer' },
  { id: 'primary-consumers', y: -0.5, size: 1.8, color: '#8FAE3A', label: 'Grasshopper — Primary Consumer' },
  { id: 'secondary-consumers', y: -0.1, size: 1.3, color: '#D4942A', label: 'Frog — Secondary Consumer' },
  { id: 'tertiary-consumers', y: 0.3, size: 0.85, color: '#B5402E', label: 'Snake & Eagle — Tertiary Consumers' },
];

export default function FoodChainPyramid({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group position={[0, 0.3, 0]}>
      {tiers.map((tier) => (
        <group key={tier.id}>
          <mesh position={[0, tier.y, 0]} onClick={pick(tier.id)}>
            <boxGeometry args={[tier.size, 0.26, tier.size]} />
            <meshStandardMaterial
              color={tier.color}
              roughness={0.55}
              emissive={sel(tier.id) ? tier.color : '#000000'}
              emissiveIntensity={0.25}
            />
          </mesh>
          {showLabels && (
            <LabelMarker
              position={[tier.size / 2 + 0.5, tier.y, 0]}
              label={tier.label}
              active={sel(tier.id)}
              onClick={() => onSelectComponent(tier.id)}
            />
          )}
        </group>
      ))}
      {tiers.slice(0, -1).map((tier, i) => (
        <mesh key={i} position={[0, tier.y + 0.2, 0]}>
          <coneGeometry args={[0.07, 0.2, 10]} />
          <meshStandardMaterial color="#F4F6F8" />
        </mesh>
      ))}
    </group>
  );
}
