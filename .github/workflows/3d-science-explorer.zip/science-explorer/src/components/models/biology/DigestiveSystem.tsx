import TubePath from '../shared/TubePath';
import LabelMarker from '../shared/LabelMarker';
import { helixPoints, path } from '../../../utils/geometry';
import type { ModelViewProps } from '../../../types';

const oesophagus = path([0, 2.3, 0], [0.05, 1.7, 0], [0.12, 1.05, 0]);
const smallIntestine = helixPoints({ turns: 3, radius: 0.32, height: -1.2, center: [0.15, 0.35, 0] });
const largeIntestine = path([0.15, -0.85, 0], [0.95, -0.85, 0], [0.95, 0.85, 0], [-0.75, 0.85, 0], [-0.75, -0.6, 0]);

export default function DigestiveSystem({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh position={[0, 2.45, 0]} onClick={pick('mouth')}>
        <sphereGeometry args={[0.22, 20, 20]} />
        <meshStandardMaterial color="#C97B5A" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[0, 2.75, 0]} label="Mouth" active={sel('mouth')} onClick={() => onSelectComponent('mouth')} />}

      <group onClick={pick('oesophagus')}>
        <TubePath points={oesophagus} radius={0.1} color="#C98A2E" />
      </group>
      {showLabels && (
        <LabelMarker position={[0.3, 1.7, 0]} label="Oesophagus" active={sel('oesophagus')} onClick={() => onSelectComponent('oesophagus')} />
      )}

      <mesh position={[0.2, 0.75, 0]} onClick={pick('stomach')}>
        <sphereGeometry args={[0.38, 24, 24]} />
        <meshStandardMaterial color="#D08A3E" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[0.2, 1.2, 0]} label="Stomach" active={sel('stomach')} onClick={() => onSelectComponent('stomach')} />}

      <group onClick={pick('small-intestine')}>
        <TubePath points={smallIntestine} radius={0.07} color="#E0A857" />
      </group>
      {showLabels && (
        <LabelMarker position={[0.5, -0.1, 0]} label="Small Intestine" active={sel('small-intestine')} onClick={() => onSelectComponent('small-intestine')} />
      )}

      <group onClick={pick('large-intestine')}>
        <TubePath points={largeIntestine} radius={0.11} color="#8B6A4A" />
      </group>
      {showLabels && (
        <LabelMarker position={[0.95, -1.1, 0]} label="Large Intestine" active={sel('large-intestine')} onClick={() => onSelectComponent('large-intestine')} />
      )}

      <mesh position={[0.78, 1.05, 0.2]} scale={[1, 0.6, 0.6]} onClick={pick('liver')}>
        <sphereGeometry args={[0.32, 20, 20]} />
        <meshStandardMaterial color="#8E3A3A" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[0.95, 1.3, 0.3]} label="Liver" active={sel('liver')} onClick={() => onSelectComponent('liver')} />}

      <mesh position={[-0.35, 0.35, 0.18]} scale={[1.3, 0.5, 0.5]} onClick={pick('pancreas')}>
        <sphereGeometry args={[0.2, 18, 18]} />
        <meshStandardMaterial color="#E3C6B8" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[-0.55, 0.55, 0.3]} label="Pancreas" active={sel('pancreas')} onClick={() => onSelectComponent('pancreas')} />}
    </group>
  );
}
