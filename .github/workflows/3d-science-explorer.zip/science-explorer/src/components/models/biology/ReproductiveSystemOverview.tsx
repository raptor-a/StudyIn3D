import TubePath from '../shared/TubePath';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

export default function ReproductiveSystemOverview({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh position={[0, 0.4, 0]} scale={[0.45, 0.6, 0.35]} onClick={pick('uterus')}>
        <sphereGeometry args={[0.5, 24, 24]} />
        <meshStandardMaterial color="#C98A9A" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[0, 1.0, 0]} label="Uterus" active={sel('uterus')} onClick={() => onSelectComponent('uterus')} />}

      <group onClick={pick('fallopian-tube')}>
        <TubePath points={[[-0.35, 0.75, 0], [-0.75, 0.95, 0.1], [-1.1, 0.8, 0.15]]} radius={0.06} color="#D8A4B0" />
        <TubePath points={[[0.35, 0.75, 0], [0.75, 0.95, 0.1], [1.1, 0.8, 0.15]]} radius={0.06} color="#D8A4B0" />
      </group>
      {showLabels && (
        <LabelMarker position={[-0.9, 1.15, 0.15]} label="Fallopian Tube" active={sel('fallopian-tube')} onClick={() => onSelectComponent('fallopian-tube')} />
      )}

      <mesh position={[-1.15, 0.75, 0.15]} onClick={pick('ovary')}>
        <sphereGeometry args={[0.16, 18, 18]} />
        <meshStandardMaterial color="#E8B8A0" roughness={0.5} />
      </mesh>
      <mesh position={[1.15, 0.75, 0.15]} onClick={pick('ovary')}>
        <sphereGeometry args={[0.16, 18, 18]} />
        <meshStandardMaterial color="#E8B8A0" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[1.15, 1.0, 0.15]} label="Ovary" active={sel('ovary')} onClick={() => onSelectComponent('ovary')} />}

      <mesh position={[0, -0.85, 0.3]} scale={[0.38, 0.28, 0.28]} onClick={pick('testis')}>
        <sphereGeometry args={[0.5, 20, 20]} />
        <meshStandardMaterial color="#D8B898" roughness={0.5} />
      </mesh>
      {showLabels && <LabelMarker position={[0, -1.15, 0.3]} label="Testis" active={sel('testis')} onClick={() => onSelectComponent('testis')} />}
    </group>
  );
}
