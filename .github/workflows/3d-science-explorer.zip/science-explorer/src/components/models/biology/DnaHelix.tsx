import TubePath from '../shared/TubePath';
import LabelMarker from '../shared/LabelMarker';
import { helixPoints } from '../../../utils/geometry';
import type { ModelViewProps } from '../../../types';

const BASE_COLORS = ['#D13B3B', '#2D7DD2', '#2E9E5B', '#D4A72C'];

const strand1 = helixPoints({ turns: 4, radius: 0.6, height: 4, center: [0, -2, 0], phase: 0 });
const strand2 = helixPoints({ turns: 4, radius: 0.6, height: 4, center: [0, -2, 0], phase: Math.PI });

const rungIndices: number[] = [];
for (let i = 1; i < strand1.length - 1; i += 3) rungIndices.push(i);

export default function DnaHelix({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <group onClick={pick('backbone')}>
        <TubePath points={strand1} radius={0.07} color="#8B95A5" />
        <TubePath points={strand2} radius={0.07} color="#5B6472" />
      </group>
      {showLabels && (
        <LabelMarker position={[0, 2.25, 0]} label="Sugar-Phosphate Backbone" active={sel('backbone')} onClick={() => onSelectComponent('backbone')} />
      )}

      <group onClick={pick('base-pairs')}>
        {rungIndices.map((i, idx) => (
          <TubePath key={i} points={[strand1[i], strand2[i]]} radius={0.035} color={BASE_COLORS[idx % BASE_COLORS.length]} />
        ))}
      </group>
      {showLabels && (
        <LabelMarker position={[0.95, 0, 0]} label="Base Pairs" active={sel('base-pairs')} onClick={() => onSelectComponent('base-pairs')} />
      )}
    </group>
  );
}
