import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';
import type { Pt3 } from '../../../utils/geometry';

function useCurve(points: Pt3[]) {
  return useMemo(() => new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(p[0], p[1], p[2]))), [points]);
}

function Vessel({ points, color, radius = 0.09 }: { points: Pt3[]; color: string; radius?: number }) {
  const curve = useCurve(points);
  const geometry = useMemo(() => new THREE.TubeGeometry(curve, 48, radius, 8, false), [curve, radius]);
  return (
    <mesh geometry={geometry}>
      <meshStandardMaterial color={color} roughness={0.4} />
    </mesh>
  );
}

function FlowParticles({ points, color, count = 3, speed = 0.18, offset = 0 }: { points: Pt3[]; color: string; count?: number; speed?: number; offset?: number }) {
  const curve = useCurve(points);
  const refs = useRef<(THREE.Mesh | null)[]>([]);
  useFrame(({ clock }) => {
    for (let i = 0; i < count; i++) {
      const t = (clock.elapsedTime * speed + offset + i / count) % 1;
      const p = curve.getPointAt(t);
      const mesh = refs.current[i];
      if (mesh) mesh.position.copy(p);
    }
  });
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <mesh
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
        >
          <sphereGeometry args={[0.045, 10, 10]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.7} />
        </mesh>
      ))}
    </>
  );
}

const aorta: Pt3[] = [[0.25, 0.25, 0], [0.4, 1.1, 0], [-0.05, 1.75, 0], [-0.85, 1.55, 0.15]];
const pulmonaryArtery: Pt3[] = [[-0.25, 0.3, 0], [-0.5, 0.95, -0.1], [-0.95, 1.2, -0.35], [-1.3, 1.0, -0.4]];
const venaCava: Pt3[] = [[-0.95, 1.95, 0], [-0.65, 1.35, 0], [-0.4, 0.85, 0]];
const pulmonaryVein: Pt3[] = [[0.95, 1.7, 0.3], [0.6, 1.2, 0.15], [0.35, 0.9, 0]];

export default function HumanHeart({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh position={[-0.4, 0.7, 0]} onClick={pick('right-atrium')}>
        <sphereGeometry args={[0.4, 28, 28]} />
        <meshStandardMaterial color="#9B3A3A" roughness={0.5} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[-0.4, 1.15, 0]} label="Right Atrium" active={sel('right-atrium')} onClick={() => onSelectComponent('right-atrium')} />
      )}

      <mesh position={[0.35, 0.75, 0]} onClick={pick('left-atrium')}>
        <sphereGeometry args={[0.4, 28, 28]} />
        <meshStandardMaterial color="#C23B3B" roughness={0.5} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0.35, 1.2, 0]} label="Left Atrium" active={sel('left-atrium')} onClick={() => onSelectComponent('left-atrium')} />
      )}

      <mesh position={[-0.25, -0.1, 0]} rotation={[Math.PI, 0, 0]} onClick={pick('right-ventricle')}>
        <coneGeometry args={[0.38, 1.1, 24]} />
        <meshStandardMaterial color="#8E3333" roughness={0.5} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[-0.55, -0.4, 0]} label="Right Ventricle" active={sel('right-ventricle')} onClick={() => onSelectComponent('right-ventricle')} />
      )}

      <mesh position={[0.2, -0.2, 0]} rotation={[Math.PI, 0, 0]} onClick={pick('left-ventricle')}>
        <coneGeometry args={[0.45, 1.3, 24]} />
        <meshStandardMaterial color="#A83939" roughness={0.5} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0.55, -0.5, 0]} label="Left Ventricle" active={sel('left-ventricle')} onClick={() => onSelectComponent('left-ventricle')} />
      )}

      <mesh position={[-0.03, 0.05, 0.02]} onClick={pick('septum')}>
        <boxGeometry args={[0.08, 1.05, 0.5]} />
        <meshStandardMaterial color="#6E2727" roughness={0.6} />
      </mesh>
      {showLabels && <LabelMarker position={[0, -0.9, 0.3]} label="Septum" active={sel('septum')} onClick={() => onSelectComponent('septum')} />}

      <group onClick={pick('aorta')}>
        <Vessel points={aorta} color="#D13B3B" />
      </group>
      {showLabels && <LabelMarker position={[-0.85, 1.85, 0.15]} label="Aorta" active={sel('aorta')} onClick={() => onSelectComponent('aorta')} />}

      <group onClick={pick('pulmonary-artery')}>
        <Vessel points={pulmonaryArtery} color="#2D5FA3" />
      </group>
      {showLabels && (
        <LabelMarker position={[-1.3, 1.25, -0.4]} label="Pulmonary Artery" active={sel('pulmonary-artery')} onClick={() => onSelectComponent('pulmonary-artery')} />
      )}

      <Vessel points={venaCava} color="#2D5FA3" radius={0.08} />
      <Vessel points={pulmonaryVein} color="#D13B3B" radius={0.08} />

      <FlowParticles points={aorta} color="#FF8A8A" speed={0.22} />
      <FlowParticles points={pulmonaryArtery} color="#8AB4FF" speed={0.2} offset={0.4} />
      <FlowParticles points={venaCava} color="#8AB4FF" speed={0.25} offset={0.1} count={2} />
      <FlowParticles points={pulmonaryVein} color="#FF8A8A" speed={0.25} offset={0.6} count={2} />
    </group>
  );
}
