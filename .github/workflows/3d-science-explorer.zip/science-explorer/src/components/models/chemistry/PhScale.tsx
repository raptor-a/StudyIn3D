import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const PH_COLORS = [
  '#D13B3B', '#DA4A33', '#E35A2B', '#EC7A23', '#F0981B', '#F0B51A', '#E8CB1E',
  '#8FC23A',
  '#4FAE5E', '#2D9E78', '#1E8E9A', '#1E6FA8', '#1E4D8C', '#3A3A9E', '#5B2E8C',
];

export default function PhScale({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };
  const zoneFor = (ph: number) => (ph < 7 ? 'acidic-zone' : ph === 7 ? 'neutral-point' : 'basic-zone');

  return (
    <group>
      {PH_COLORS.map((color, ph) => {
        const x = (ph - 7) * 0.34;
        const zone = zoneFor(ph);
        return (
          <group key={ph}>
            <mesh position={[x, 0, 0]} onClick={pick(zone)}>
              <sphereGeometry args={[0.15, 20, 20]} />
              <meshStandardMaterial color={color} roughness={0.3} emissive={sel(zone) ? color : '#000000'} emissiveIntensity={0.3} />
            </mesh>
            {showLabels && (
              <LabelMarker position={[x, -0.35, 0]} label={String(ph)} active={sel(zone)} onClick={() => onSelectComponent(zone)} />
            )}
          </group>
        );
      })}
      {showLabels && (
        <LabelMarker position={[(2 - 7) * 0.34, 0.4, 0]} label="Lemon juice" active={sel('acidic-zone')} onClick={() => onSelectComponent('acidic-zone')} />
      )}
      {showLabels && (
        <LabelMarker position={[0, 0.4, 0]} label="Pure water" active={sel('neutral-point')} onClick={() => onSelectComponent('neutral-point')} />
      )}
      {showLabels && (
        <LabelMarker position={[(10 - 7) * 0.34, 0.4, 0]} label="Soap" active={sel('basic-zone')} onClick={() => onSelectComponent('basic-zone')} />
      )}
    </group>
  );
}
