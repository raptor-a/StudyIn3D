import { useMemo } from 'react';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const SIZE = 3;
const SPACING = 0.55;

export default function IonicLattice({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const ions = useMemo(() => {
    const list: { key: string; position: [number, number, number]; isSodium: boolean }[] = [];
    const offset = ((SIZE - 1) * SPACING) / 2;
    for (let x = 0; x < SIZE; x++) {
      for (let y = 0; y < SIZE; y++) {
        for (let z = 0; z < SIZE; z++) {
          list.push({
            key: `${x}-${y}-${z}`,
            position: [x * SPACING - offset, y * SPACING - offset, z * SPACING - offset],
            isSodium: (x + y + z) % 2 === 0,
          });
        }
      }
    }
    return list;
  }, []);

  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      {ions.map((ion) => (
        <mesh key={ion.key} position={ion.position} onClick={pick(ion.isSodium ? 'sodium-ion' : 'chloride-ion')}>
          <sphereGeometry args={[ion.isSodium ? 0.13 : 0.22, 20, 20]} />
          <meshStandardMaterial
            color={ion.isSodium ? '#7A4AC9' : '#2E9E5B'}
            roughness={0.3}
            emissive={sel(ion.isSodium ? 'sodium-ion' : 'chloride-ion') ? (ion.isSodium ? '#7A4AC9' : '#2E9E5B') : '#000000'}
            emissiveIntensity={0.35}
          />
        </mesh>
      ))}
      {showLabels && (
        <LabelMarker position={[0, -1.3, 0]} label="Na⁺ (small, violet)" active={sel('sodium-ion')} onClick={() => onSelectComponent('sodium-ion')} />
      )}
      {showLabels && (
        <LabelMarker position={[0, 1.3, 0]} label="Cl⁻ (large, green)" active={sel('chloride-ion')} onClick={() => onSelectComponent('chloride-ion')} />
      )}
    </group>
  );
}
