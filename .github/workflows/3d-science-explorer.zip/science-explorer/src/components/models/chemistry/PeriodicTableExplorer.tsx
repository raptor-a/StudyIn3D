import { useState } from 'react';
import AtomModel from '../shared/AtomModel';
import ModelHud from '../shared/ModelHud';
import LabelMarker from '../shared/LabelMarker';
import { elements } from '../../../data/elements';
import type { ModelViewProps } from '../../../types';

const categoryColor: Record<string, string> = {
  metal: '#1E4D8C',
  nonmetal: '#1F6E43',
  metalloid: '#A3650E',
  'noble-gas': '#6B4C9A',
};

export default function PeriodicTableExplorer({ showLabels, onSelectComponent }: ModelViewProps) {
  const [view, setView] = useState<'table' | 'atom'>('table');
  const [activeZ, setActiveZ] = useState(6);
  const active = elements.find((el) => el.atomicNumber === activeZ) ?? elements[5];

  const colOffset = 3.5 * 0.56;
  const rowOffset = 1.5 * 0.56;

  return (
    <group>
      <ModelHud
        options={[
          {
            label: 'Element Grid',
            active: view === 'table',
            onClick: () => {
              setView('table');
              onSelectComponent('tile-grid');
            },
          },
          {
            label: `Atom: ${active.symbol}`,
            active: view === 'atom',
            onClick: () => {
              setView('atom');
              onSelectComponent('atom-view');
            },
          },
        ]}
      />

      {view === 'table' && (
        <group>
          {elements.map((el) => {
            const x = (el.group - 1) * 0.56 - colOffset;
            const y = rowOffset - (el.period - 1) * 0.56;
            return (
              <group
                key={el.symbol}
                position={[x, y, 0]}
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveZ(el.atomicNumber);
                  setView('atom');
                  onSelectComponent('atom-view');
                }}
              >
                <mesh>
                  <boxGeometry args={[0.5, 0.5, 0.08]} />
                  <meshStandardMaterial color={categoryColor[el.category]} roughness={0.4} />
                </mesh>
                {showLabels && <LabelMarker position={[0, 0, 0.2]} label={el.symbol} />}
              </group>
            );
          })}
        </group>
      )}

      {view === 'atom' && <AtomModel atomicNumber={active.atomicNumber} symbol={active.symbol} showLabels={showLabels} />}
    </group>
  );
}
