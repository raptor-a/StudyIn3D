import { useState } from 'react';
import Molecule3D, { type MoleculeAtom, type MoleculeBond } from '../shared/Molecule3D';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

const atoms: MoleculeAtom[] = [
  { id: 'c1', group: 'double-bond-carbons', symbol: 'C', color: '#2B2F36', radius: 0.21, position: [-0.65, 0, 0] },
  { id: 'c2', group: 'double-bond-carbons', symbol: 'C', color: '#2B2F36', radius: 0.21, position: [0.65, 0, 0] },
  { id: 'h1', group: 'hydrogens-ethene', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [-1.25, 0.5, 0] },
  { id: 'h2', group: 'hydrogens-ethene', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [-1.25, -0.5, 0] },
  { id: 'h3', group: 'hydrogens-ethene', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [1.25, 0.5, 0] },
  { id: 'h4', group: 'hydrogens-ethene', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [1.25, -0.5, 0] },
];
const bonds: MoleculeBond[] = [
  { from: 'c1', to: 'c2', order: 2 },
  { from: 'c1', to: 'h1' },
  { from: 'c1', to: 'h2' },
  { from: 'c2', to: 'h3' },
  { from: 'c2', to: 'h4' },
];

export default function Ethene({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [viewMode, setViewMode] = useState<'ball-stick' | 'space-filling'>('ball-stick');
  return (
    <group>
      <ModelHud
        options={[
          { label: 'Ball & Stick', active: viewMode === 'ball-stick', onClick: () => setViewMode('ball-stick') },
          { label: 'Space-Filling', active: viewMode === 'space-filling', onClick: () => setViewMode('space-filling') },
        ]}
      />
      <Molecule3D
        atoms={atoms}
        bonds={bonds}
        viewMode={viewMode}
        showLabels={showLabels}
        selectedComponent={selectedComponent}
        onSelectComponent={onSelectComponent}
      />
    </group>
  );
}
