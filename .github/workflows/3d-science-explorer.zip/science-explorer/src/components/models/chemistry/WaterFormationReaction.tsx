import { Line } from '@react-three/drei';
import Molecule3D, { type MoleculeAtom, type MoleculeBond } from '../shared/Molecule3D';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const H = '#F4F6F8';
const O = '#D13B3B';

const atoms: MoleculeAtom[] = [
  // reactants: 2x H2
  { id: 'h2a-1', group: 'reactant-h2-a', symbol: 'H', color: H, radius: 0.12, position: [-2.85, 0.6, 0] },
  { id: 'h2a-2', group: 'reactant-h2-a', symbol: 'H', color: H, radius: 0.12, position: [-2.5, 0.6, 0] },
  { id: 'h2b-1', group: 'reactant-h2-a', symbol: 'H', color: H, radius: 0.12, position: [-2.85, -0.6, 0] },
  { id: 'h2b-2', group: 'reactant-h2-a', symbol: 'H', color: H, radius: 0.12, position: [-2.5, -0.6, 0] },
  // reactant: O2
  { id: 'o2-1', group: 'reactant-o2', symbol: 'O', color: O, radius: 0.19, position: [-1.95, 0, 0.3] },
  { id: 'o2-2', group: 'reactant-o2', symbol: 'O', color: O, radius: 0.19, position: [-1.6, 0, 0.3] },
  // products: 2x H2O
  { id: 'w1-o', group: 'product-h2o-a', symbol: 'O', color: O, radius: 0.19, position: [1.6, 0.4, 0] },
  { id: 'w1-h1', group: 'product-h2o-a', symbol: 'H', color: H, radius: 0.11, position: [1.95, 0.65, 0] },
  { id: 'w1-h2', group: 'product-h2o-a', symbol: 'H', color: H, radius: 0.11, position: [1.25, 0.65, 0] },
  { id: 'w2-o', group: 'product-h2o-a', symbol: 'O', color: O, radius: 0.19, position: [1.6, -0.5, 0.3] },
  { id: 'w2-h1', group: 'product-h2o-a', symbol: 'H', color: H, radius: 0.11, position: [1.95, -0.25, 0.3] },
  { id: 'w2-h2', group: 'product-h2o-a', symbol: 'H', color: H, radius: 0.11, position: [1.25, -0.25, 0.3] },
];

const bonds: MoleculeBond[] = [
  { from: 'h2a-1', to: 'h2a-2' },
  { from: 'h2b-1', to: 'h2b-2' },
  { from: 'o2-1', to: 'o2-2', order: 2 },
  { from: 'w1-o', to: 'w1-h1' },
  { from: 'w1-o', to: 'w1-h2' },
  { from: 'w2-o', to: 'w2-h1' },
  { from: 'w2-o', to: 'w2-h2' },
];

export default function WaterFormationReaction({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  return (
    <group>
      <Molecule3D
        atoms={atoms}
        bonds={bonds}
        viewMode="ball-stick"
        showLabels={showLabels}
        selectedComponent={selectedComponent}
        onSelectComponent={onSelectComponent}
      />
      <Line points={[[-1.2, 0, 0.15], [0.9, 0, 0.15]]} color="#9CA7B5" lineWidth={2} />
      <mesh position={[0.95, 0, 0.15]} rotation={[0, 0, -Math.PI / 2]}>
        <coneGeometry args={[0.08, 0.2, 10]} />
        <meshStandardMaterial color="#9CA7B5" />
      </mesh>
      {showLabels && <LabelMarker position={[-2.2, -1.0, 0]} label="Reactants" />}
      {showLabels && <LabelMarker position={[1.6, -1.0, 0]} label="Products" />}
    </group>
  );
}
