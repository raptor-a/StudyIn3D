import { useState } from 'react';
import Molecule3D, { type MoleculeAtom, type MoleculeBond } from '../shared/Molecule3D';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

const atoms: MoleculeAtom[] = [
  { id: 'c1', group: 'carbon-chain', symbol: 'C', color: '#2B2F36', radius: 0.21, position: [-0.9, 0, 0] },
  { id: 'c2', group: 'carbon-chain', symbol: 'C', color: '#2B2F36', radius: 0.21, position: [0, 0, 0] },
  { id: 'o', group: 'hydroxyl', symbol: 'O', color: '#D13B3B', radius: 0.2, position: [0.75, 0.55, 0] },
  { id: 'h-oh', group: 'hydroxyl', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [1.3, 0.85, 0.3] },
  { id: 'h-c1-a', group: 'hydrogens', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [-1.45, 0.45, 0.4] },
  { id: 'h-c1-b', group: 'hydrogens', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [-1.45, 0.45, -0.4] },
  { id: 'h-c1-c', group: 'hydrogens', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [-1.45, -0.55, 0] },
  { id: 'h-c2-a', group: 'hydrogens', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [0.05, -0.55, 0.45] },
  { id: 'h-c2-b', group: 'hydrogens', symbol: 'H', color: '#F4F6F8', radius: 0.11, position: [0.05, -0.55, -0.45] },
];
const bonds: MoleculeBond[] = [
  { from: 'c1', to: 'c2' },
  { from: 'c2', to: 'o' },
  { from: 'o', to: 'h-oh' },
  { from: 'c1', to: 'h-c1-a' },
  { from: 'c1', to: 'h-c1-b' },
  { from: 'c1', to: 'h-c1-c' },
  { from: 'c2', to: 'h-c2-a' },
  { from: 'c2', to: 'h-c2-b' },
];

export default function Ethanol({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [viewMode, setViewMode] = useState<'ball-stick' | 'space-filling'>('ball-stick');
  return (
    <group>
      <ModelHud
        options={[
          { label: 'Ball & Stick', active: viewMode === 'ball-stick', onClick: () => setViewMode('ball-stick') },
          { label: 'Space-Filling', active: viewMode === 'space-filling', onClick: () => setViewMode('space-filling') },
        ]}
      />
      <Molecule3D
        atoms={atoms}
        bonds={bonds}
        viewMode={viewMode}
        showLabels={showLabels}
        selectedComponent={selectedComponent}
        onSelectComponent={onSelectComponent}
      />
    </group>
  );
}
