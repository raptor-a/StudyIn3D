import { useState } from 'react';
import Molecule3D, { type MoleculeAtom, type MoleculeBond } from '../shared/Molecule3D';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

const atoms: MoleculeAtom[] = [
  { id: 'c', group: 'carbon', symbol: 'C', color: '#2B2F36', radius: 0.22, position: [0, 0, 0] },
  { id: 'h1', group: 'hydrogen', symbol: 'H', color: '#F4F6F8', radius: 0.12, position: [0.52, 0.52, 0.52] },
  { id: 'h2', group: 'hydrogen', symbol: 'H', color: '#F4F6F8', radius: 0.12, position: [0.52, -0.52, -0.52] },
  { id: 'h3', group: 'hydrogen', symbol: 'H', color: '#F4F6F8', radius: 0.12, position: [-0.52, 0.52, -0.52] },
  { id: 'h4', group: 'hydrogen', symbol: 'H', color: '#F4F6F8', radius: 0.12, position: [-0.52, -0.52, 0.52] },
];
const bonds: MoleculeBond[] = [
  { from: 'c', to: 'h1' },
  { from: 'c', to: 'h2' },
  { from: 'c', to: 'h3' },
  { from: 'c', to: 'h4' },
];

export default function Methane({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [viewMode, setViewMode] = useState<'ball-stick' | 'space-filling'>('ball-stick');
  return (
    <group>
      <ModelHud
        options={[
          { label: 'Ball & Stick', active: viewMode === 'ball-stick', onClick: () => setViewMode('ball-stick') },
          { label: 'Space-Filling', active: viewMode === 'space-filling', onClick: () => setViewMode('space-filling') },
        ]}
      />
      <Molecule3D
        atoms={atoms}
        bonds={bonds}
        viewMode={viewMode}
        showLabels={showLabels}
        selectedComponent={selectedComponent}
        onSelectComponent={onSelectComponent}
      />
    </group>
  );
}
