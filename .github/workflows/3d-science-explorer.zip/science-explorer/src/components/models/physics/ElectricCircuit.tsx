import { useState } from 'react';
import { Line } from '@react-three/drei';
import LabelMarker from '../shared/LabelMarker';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';
import type { Pt3 } from '../../../utils/geometry';

const outerLoop: Pt3[] = [
  [-1.2, -0.8, 0],
  [-1.2, 0.8, 0],
  [1.2, 0.8, 0],
  [1.2, -0.8, 0],
  [-1.2, -0.8, 0],
];
const branchLine: Pt3[] = [
  [-1.2, 0.4, 0],
  [1.2, 0.4, 0],
];

type PartType = 'battery' | 'switch' | 'resistor' | 'bulb' | 'ammeter';
interface Part {
  id: string;
  type: PartType;
  position: Pt3;
  label: string;
}

const seriesParts: Part[] = [
  { id: 'cell', type: 'battery', position: [-1.2, 0, 0], label: 'Cell' },
  { id: 'switch', type: 'switch', position: [-0.2, -0.8, 0], label: 'Switch' },
  { id: 'resistor', type: 'resistor', position: [-0.55, 0.8, 0], label: 'Resistor' },
  { id: 'bulb', type: 'bulb', position: [0.6, 0.8, 0], label: 'Bulb' },
  { id: 'ammeter', type: 'ammeter', position: [1.2, 0, 0], label: 'Ammeter' },
];
const parallelParts: Part[] = [
  { id: 'cell', type: 'battery', position: [-1.2, 0, 0], label: 'Cell' },
  { id: 'switch', type: 'switch', position: [-0.2, -0.8, 0], label: 'Switch' },
  { id: 'bulb', type: 'bulb', position: [0, 0.8, 0], label: 'Bulb' },
  { id: 'resistor', type: 'resistor', position: [0, 0.4, 0], label: 'Resistor' },
  { id: 'ammeter', type: 'ammeter', position: [1.2, 0, 0], label: 'Ammeter' },
];

export default function ElectricCircuit({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [layout, setLayout] = useState<'series' | 'parallel'>('series');
  const [closed, setClosed] = useState(true);
  const parts = layout === 'series' ? seriesParts : parallelParts;

  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <ModelHud
        options={[
          { label: 'Series', active: layout === 'series', onClick: () => setLayout('series') },
          { label: 'Parallel', active: layout === 'parallel', onClick: () => setLayout('parallel') },
          { label: closed ? 'Switch Closed' : 'Switch Open', active: closed, onClick: () => setClosed((v) => !v) },
        ]}
      />

      <Line points={outerLoop} color="#8B95A5" lineWidth={2} />
      {layout === 'parallel' && <Line points={branchLine} color="#8B95A5" lineWidth={2} />}

      {parts.map((part) => (
        <group key={part.id} position={part.position} onClick={pick(part.id)}>
          {part.type === 'battery' && (
            <group>
              <mesh position={[0, 0.07, 0]}>
                <boxGeometry args={[0.22, 0.05, 0.12]} />
                <meshStandardMaterial color="#1E242E" />
              </mesh>
              <mesh position={[0, -0.07, 0]}>
                <boxGeometry args={[0.14, 0.05, 0.12]} />
                <meshStandardMaterial color="#1E242E" />
              </mesh>
            </group>
          )}
          {part.type === 'switch' && (
            <group>
              <mesh position={[-0.12, 0, 0]}>
                <sphereGeometry args={[0.035, 10, 10]} />
                <meshStandardMaterial color="#1E242E" />
              </mesh>
              <mesh position={[0.12, 0, 0]}>
                <sphereGeometry args={[0.035, 10, 10]} />
                <meshStandardMaterial color="#1E242E" />
              </mesh>
              <mesh position={[0, closed ? 0.0 : 0.06, 0]} rotation={[0, 0, closed ? 0 : 0.5]}>
                <cylinderGeometry args={[0.014, 0.014, 0.26, 8]} />
                <meshStandardMaterial color="#A3650E" />
              </mesh>
            </group>
          )}
          {part.type === 'resistor' && (
            <mesh>
              <boxGeometry args={[0.3, 0.1, 0.1]} />
              <meshStandardMaterial color="#D8B98A" />
            </mesh>
          )}
          {part.type === 'bulb' && (
            <mesh>
              <sphereGeometry args={[0.13, 20, 20]} />
              <meshStandardMaterial
                color="#FFF3D0"
                emissive={closed ? '#FFC94D' : '#000000'}
                emissiveIntensity={closed ? 1.1 : 0}
                transparent
                opacity={0.85}
              />
            </mesh>
          )}
          {part.type === 'ammeter' && (
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.14, 0.14, 0.06, 20]} />
              <meshStandardMaterial color="#E7EAEF" />
            </mesh>
          )}
        </group>
      ))}

      {showLabels &&
        parts.map((part) => (
          <LabelMarker
            key={part.id}
            position={[part.position[0], part.position[1] + 0.26, part.position[2]]}
            label={part.label}
            active={sel(part.id)}
            onClick={() => onSelectComponent(part.id)}
          />
        ))}
    </group>
  );
}
