import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const cols = 4;
const rows = 3;
const cellW = 0.38;
const cellH = 0.38;
const gap = 0.04;
const panelW = cols * cellW + (cols - 1) * gap;
const panelH = rows * cellH + (rows - 1) * gap;

export default function SolarPanel({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <group rotation={[-Math.PI / 5, 0, 0]} position={[0, 0.25, 0]}>
        <mesh position={[0, 0, -0.03]} onClick={pick('frame')}>
          <boxGeometry args={[panelW + 0.16, panelH + 0.16, 0.05]} />
          <meshStandardMaterial color="#4A5261" metalness={0.5} roughness={0.4} />
        </mesh>
        {showLabels && (
          <LabelMarker position={[0, panelH / 2 + 0.22, 0]} label="Frame" active={sel('frame')} onClick={() => onSelectComponent('frame')} />
        )}

        <group onClick={pick('cells')}>
          {Array.from({ length: rows }).map((_, r) =>
            Array.from({ length: cols }).map((_, c) => {
              const x = -panelW / 2 + cellW / 2 + c * (cellW + gap);
              const y = -panelH / 2 + cellH / 2 + r * (cellH + gap);
              return (
                <mesh key={`${r}-${c}`} position={[x, y, 0]}>
                  <boxGeometry args={[cellW, cellH, 0.02]} />
                  <meshStandardMaterial color="#17345E" metalness={0.6} roughness={0.25} />
                </mesh>
              );
            })
          )}
        </group>
        {showLabels && (
          <LabelMarker position={[0, 0, 0.2]} label="Photovoltaic Cells" active={sel('cells')} onClick={() => onSelectComponent('cells')} />
        )}
      </group>

      <mesh position={[0, -0.75, -0.1]} onClick={pick('stand')}>
        <cylinderGeometry args={[0.05, 0.05, 1.3, 10]} />
        <meshStandardMaterial color="#5B6472" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0.3, -1.1, -0.1]} label="Tilted Stand" active={sel('stand')} onClick={() => onSelectComponent('stand')} />
      )}
    </group>
  );
}
