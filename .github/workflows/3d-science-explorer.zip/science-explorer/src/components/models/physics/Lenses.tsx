import { useState } from 'react';
import { Line } from '@react-three/drei';
import LabelMarker from '../shared/LabelMarker';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

const F = 1.0;

export default function Lenses({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [lensType, setLensType] = useState<'convex' | 'concave'>('convex');
  const isConvex = lensType === 'convex';

  const objectY = -F * 2.6;
  const objectTipX = 0.5;
  const imageY = isConvex ? F * 1.3 : -F * 0.45;
  const imageTipX = isConvex ? -0.3 : 0.2;

  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <ModelHud
        options={[
          { label: 'Convex', active: isConvex, onClick: () => setLensType('convex') },
          { label: 'Concave', active: !isConvex, onClick: () => setLensType('concave') },
        ]}
      />

      <mesh scale={[1, 0.26, 1]} onClick={pick('optical-centre')}>
        <sphereGeometry args={[0.95, 36, 36]} />
        <meshStandardMaterial
          color={isConvex ? '#BFE3FF' : '#E6D2F3'}
          transparent
          opacity={0.5}
          roughness={0.15}
        />
      </mesh>

      <Line points={[[0, -F * 3, 0], [0, F * 3, 0]]} color="#495363" lineWidth={1} dashed dashSize={0.08} gapSize={0.06} />

      <mesh position={[0, 0, 0]} onClick={pick('optical-centre')}>
        <sphereGeometry args={[0.045, 16, 16]} />
        <meshStandardMaterial color="#1E4D8C" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, 0, 0.3]} label="Optical Centre" active={sel('optical-centre')} onClick={() => onSelectComponent('optical-centre')} />
      )}

      {[F, -F].map((y, i) => (
        <mesh key={i} position={[0, y, 0]} onClick={pick('focus-1')}>
          <sphereGeometry args={[0.045, 16, 16]} />
          <meshStandardMaterial color="#1F6E43" />
        </mesh>
      ))}
      {showLabels && (
        <LabelMarker position={[0, F, 0.3]} label="Focus (F)" active={sel('focus-1')} onClick={() => onSelectComponent('focus-1')} />
      )}

      {[2 * F, -2 * F].map((y, i) => (
        <mesh key={i} position={[0, y, 0]} onClick={pick('focus-2')}>
          <sphereGeometry args={[0.04, 16, 16]} />
          <meshStandardMaterial color="#A3650E" />
        </mesh>
      ))}
      {showLabels && (
        <LabelMarker position={[0, 2 * F, 0.3]} label="2F" active={sel('focus-2')} onClick={() => onSelectComponent('focus-2')} />
      )}

      <mesh position={[objectTipX / 2, objectY, 0]} rotation={[0, 0, -Math.PI / 2]} onClick={pick('object')}>
        <coneGeometry args={[0.07, objectTipX, 14]} />
        <meshStandardMaterial color="#1E4D8C" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[objectTipX, objectY, 0]} label="Object" active={sel('object')} onClick={() => onSelectComponent('object')} />
      )}

      <mesh
        position={[imageTipX / 2, imageY, 0]}
        rotation={[0, 0, imageTipX > 0 ? -Math.PI / 2 : Math.PI / 2]}
        onClick={pick('image')}
      >
        <coneGeometry args={[0.055, Math.abs(imageTipX), 14]} />
        <meshStandardMaterial color="#A3650E" transparent opacity={isConvex ? 0.95 : 0.55} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[imageTipX, imageY, 0]} label="Image" active={sel('image')} onClick={() => onSelectComponent('image')} />
      )}

      <Line points={[[objectTipX, objectY, 0], [objectTipX, 0, 0], [imageTipX, imageY, 0]]} color="#D04343" lineWidth={1.5} />
      <Line points={[[objectTipX, objectY, 0], [0, 0, 0], [imageTipX, imageY, 0]]} color="#2D7DD2" lineWidth={1.5} />
    </group>
  );
}
