import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import LabelMarker from '../shared/LabelMarker';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

export default function ElectricMotor({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [running, setRunning] = useState(true);
  const armatureRef = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (running && armatureRef.current) {
      armatureRef.current.rotation.y += delta * 2.4;
    }
  });

  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <ModelHud options={[{ label: running ? 'Running' : 'Stopped — tap to run', active: running, onClick: () => setRunning((v) => !v) }]} />

      <mesh onClick={pick('axle')}>
        <cylinderGeometry args={[0.05, 0.05, 2.6, 12]} />
        <meshStandardMaterial color="#8B95A5" metalness={0.5} roughness={0.4} />
      </mesh>
      {showLabels && <LabelMarker position={[0, 1.4, 0]} label="Axle" active={sel('axle')} onClick={() => onSelectComponent('axle')} />}

      <mesh position={[-1.35, 0, 0]} onClick={pick('magnet-n')}>
        <boxGeometry args={[0.4, 1.2, 0.5]} />
        <meshStandardMaterial color="#C0392B" />
      </mesh>
      {showLabels && <LabelMarker position={[-1.35, 0.75, 0]} label="N Pole" active={sel('magnet-n')} onClick={() => onSelectComponent('magnet-n')} />}
      <mesh position={[1.35, 0, 0]} onClick={pick('magnet-s')}>
        <boxGeometry args={[0.4, 1.2, 0.5]} />
        <meshStandardMaterial color="#2D5FA3" />
      </mesh>
      {showLabels && <LabelMarker position={[1.35, 0.75, 0]} label="S Pole" active={sel('magnet-s')} onClick={() => onSelectComponent('magnet-s')} />}

      <group ref={armatureRef} onClick={pick('armature')}>
        <mesh position={[-0.5, 0, 0]}>
          <cylinderGeometry args={[0.035, 0.035, 1.2, 10]} />
          <meshStandardMaterial color="#D4A72C" metalness={0.6} roughness={0.3} />
        </mesh>
        <mesh position={[0.5, 0, 0]}>
          <cylinderGeometry args={[0.035, 0.035, 1.2, 10]} />
          <meshStandardMaterial color="#D4A72C" metalness={0.6} roughness={0.3} />
        </mesh>
        <mesh position={[0, 0.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.035, 0.035, 1.0, 10]} />
          <meshStandardMaterial color="#D4A72C" metalness={0.6} roughness={0.3} />
        </mesh>
        <mesh position={[0, -0.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.035, 0.035, 1.0, 10]} />
          <meshStandardMaterial color="#D4A72C" metalness={0.6} roughness={0.3} />
        </mesh>

        <mesh position={[0, -1.15, 0]}>
          <cylinderGeometry args={[0.14, 0.14, 0.22, 16, 1, false, 0, Math.PI]} />
          <meshStandardMaterial color="#B5761F" metalness={0.5} roughness={0.35} />
        </mesh>
        <mesh position={[0, -1.15, 0]}>
          <cylinderGeometry args={[0.14, 0.14, 0.22, 16, 1, false, Math.PI, Math.PI]} />
          <meshStandardMaterial color="#5A4121" metalness={0.5} roughness={0.35} />
        </mesh>
      </group>
      {showLabels && <LabelMarker position={[0.7, 0.2, 0]} label="Armature Coil" active={sel('armature')} onClick={() => onSelectComponent('armature')} />}
      {showLabels && (
        <LabelMarker position={[0, -1.15, 0.3]} label="Commutator" active={sel('commutator')} onClick={() => onSelectComponent('commutator')} />
      )}

      <mesh position={[0.22, -1.15, 0]} onClick={pick('brushes')}>
        <boxGeometry args={[0.12, 0.1, 0.14]} />
        <meshStandardMaterial color="#2B2F36" />
      </mesh>
      <mesh position={[-0.22, -1.15, 0]} onClick={pick('brushes')}>
        <boxGeometry args={[0.12, 0.1, 0.14]} />
        <meshStandardMaterial color="#2B2F36" />
      </mesh>
      {showLabels && <LabelMarker position={[0.4, -1.4, 0]} label="Brushes" active={sel('brushes')} onClick={() => onSelectComponent('brushes')} />}
    </group>
  );
}
