import * as THREE from 'three';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

export default function HumanEye({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      {/* sclera - semi transparent outer shell so inner parts are visible */}
      <mesh onClick={pick('retina')}>
        <sphereGeometry args={[1, 40, 40]} />
        <meshStandardMaterial color="#F3EFE3" transparent opacity={0.22} roughness={0.5} side={THREE.DoubleSide} />
      </mesh>

      {/* cornea */}
      <mesh position={[0, 0, 0.6]} rotation={[Math.PI / 2, 0, 0]} onClick={pick('cornea')}>
        <sphereGeometry args={[0.55, 32, 24, 0, Math.PI * 2, 0, Math.PI / 2.8]} />
        <meshStandardMaterial color="#CFEFFD" transparent opacity={0.4} roughness={0.1} side={THREE.DoubleSide} />
      </mesh>
      {showLabels && <LabelMarker position={[0, 0.5, 0.95]} label="Cornea" active={sel('cornea')} onClick={() => onSelectComponent('cornea')} />}

      {/* iris */}
      <mesh position={[0, 0, 0.78]} onClick={pick('iris')}>
        <ringGeometry args={[0.1, 0.42, 40]} />
        <meshStandardMaterial color="#5B3A21" side={THREE.DoubleSide} />
      </mesh>
      {showLabels && <LabelMarker position={[0.5, 0, 0.78]} label="Iris" active={sel('iris')} onClick={() => onSelectComponent('iris')} />}

      {/* pupil */}
      <mesh position={[0, 0, 0.785]} onClick={pick('pupil')}>
        <circleGeometry args={[0.1, 28]} />
        <meshStandardMaterial color="#0A0A0A" />
      </mesh>
      {showLabels && <LabelMarker position={[0, -0.25, 0.785]} label="Pupil" active={sel('pupil')} onClick={() => onSelectComponent('pupil')} />}

      {/* lens */}
      <mesh position={[0, 0, 0.55]} scale={[1, 1, 0.5]} onClick={pick('lens')}>
        <sphereGeometry args={[0.32, 24, 24]} />
        <meshStandardMaterial color="#BFE3FF" transparent opacity={0.55} roughness={0.15} />
      </mesh>
      {showLabels && <LabelMarker position={[-0.5, 0, 0.55]} label="Eye Lens" active={sel('lens')} onClick={() => onSelectComponent('lens')} />}

      {/* ciliary muscles */}
      <mesh position={[0, 0, 0.55]} onClick={pick('ciliary')}>
        <torusGeometry args={[0.4, 0.045, 10, 28]} />
        <meshStandardMaterial color="#C97B5A" />
      </mesh>
      {showLabels && <LabelMarker position={[0.55, 0.3, 0.4]} label="Ciliary Muscles" active={sel('ciliary')} onClick={() => onSelectComponent('ciliary')} />}

      {/* retina patch (back inner wall) */}
      <mesh position={[0, 0, -0.45]} rotation={[-Math.PI / 2, 0, 0]} onClick={pick('retina')}>
        <sphereGeometry args={[0.55, 32, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#B23B3B" roughness={0.6} side={THREE.DoubleSide} />
      </mesh>
      {showLabels && <LabelMarker position={[0.4, -0.4, -0.85]} label="Retina" active={sel('retina')} onClick={() => onSelectComponent('retina')} />}

      {/* optic nerve */}
      <mesh position={[0, 0, -1.3]} rotation={[Math.PI / 2, 0, 0]} onClick={pick('optic-nerve')}>
        <cylinderGeometry args={[0.15, 0.17, 0.8, 18]} />
        <meshStandardMaterial color="#E8D5B5" roughness={0.6} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, 0.3, -1.6]} label="Optic Nerve" active={sel('optic-nerve')} onClick={() => onSelectComponent('optic-nerve')} />
      )}
    </group>
  );
}
