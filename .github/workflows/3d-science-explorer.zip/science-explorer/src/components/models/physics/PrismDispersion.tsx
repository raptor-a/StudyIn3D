import { Line } from '@react-three/drei';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';

const SPECTRUM = ['#7A2FBF', '#3B4CCA', '#2D7DD2', '#1F6E43', '#D4C21F', '#E0821A', '#D13B3B'];

export default function PrismDispersion({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh rotation={[0, Math.PI / 6, 0]} onClick={pick('prism')}>
        <cylinderGeometry args={[1, 1, 1.5, 3]} />
        <meshStandardMaterial color="#DCEFFB" transparent opacity={0.4} roughness={0.08} />
      </mesh>

      <Line points={[[-2.2, 0, 0], [-0.15, 0, 0]]} color="#ffffff" lineWidth={2.5} />
      <mesh position={[-2.2, 0, 0]} onClick={pick('incident-ray')}>
        <sphereGeometry args={[0.04, 10, 10]} />
        <meshStandardMaterial color="#ffffff" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[-1.6, 0.25, 0]} label="White Light" active={sel('incident-ray')} onClick={() => onSelectComponent('incident-ray')} />
      )}

      {SPECTRUM.map((color, i) => {
        const spread = (i - (SPECTRUM.length - 1) / 2) * 0.1;
        return (
          <Line
            key={color}
            points={[
              [0.15, 0, 0],
              [2.3, spread * 3.2, 0],
            ]}
            color={color}
            lineWidth={2}
          />
        );
      })}
      <mesh position={[2.3, 0, 0]} onClick={pick('spectrum')} visible={false}>
        <sphereGeometry args={[0.3, 8, 8]} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[2.2, 1.0, 0]} label="Spectrum" active={sel('spectrum')} onClick={() => onSelectComponent('spectrum')} />
      )}
      {showLabels && (
        <LabelMarker position={[0, -1.0, 0]} label="Glass Prism" active={sel('prism')} onClick={() => onSelectComponent('prism')} />
      )}
    </group>
  );
}
