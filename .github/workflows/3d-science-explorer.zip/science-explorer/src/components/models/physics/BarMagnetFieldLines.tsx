import { Line } from '@react-three/drei';
import LabelMarker from '../shared/LabelMarker';
import type { ModelViewProps } from '../../../types';
import type { Pt3 } from '../../../utils/geometry';

function arcPoints(fromX: number, toX: number, height: number, segments = 28): Pt3[] {
  const pts: Pt3[] = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const x = fromX + (toX - fromX) * t;
    const y = Math.sin(Math.PI * t) * height;
    pts.push([x, y, 0]);
  }
  return pts;
}

const heights = [0.45, 0.85, 1.25, 1.65];

export default function BarMagnetFieldLines({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <mesh position={[-0.6, 0, 0]} onClick={pick('north-pole')}>
        <boxGeometry args={[1.2, 0.5, 0.5]} />
        <meshStandardMaterial color="#C0392B" />
      </mesh>
      <mesh position={[0.6, 0, 0]} onClick={pick('south-pole')}>
        <boxGeometry args={[1.2, 0.5, 0.5]} />
        <meshStandardMaterial color="#2D5FA3" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[-0.6, 0.4, 0]} label="North Pole" active={sel('north-pole')} onClick={() => onSelectComponent('north-pole')} />
      )}
      {showLabels && (
        <LabelMarker position={[0.6, 0.4, 0]} label="South Pole" active={sel('south-pole')} onClick={() => onSelectComponent('south-pole')} />
      )}

      {heights.map((h, i) => (
        <group key={i} onClick={pick('field-lines')}>
          <Line points={arcPoints(-1.2, 1.2, h)} color="#1E4D8C" lineWidth={1.5} />
          <Line points={arcPoints(-1.2, 1.2, h).map(([x, y, z]) => [x, -y, z] as Pt3)} color="#1E4D8C" lineWidth={1.5} />
        </group>
      ))}
      {showLabels && (
        <LabelMarker position={[0, 1.9, 0]} label="Field Lines" active={sel('field-lines')} onClick={() => onSelectComponent('field-lines')} />
      )}
    </group>
  );
}
