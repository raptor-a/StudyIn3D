import { useState } from 'react';
import { Line } from '@react-three/drei';
import * as THREE from 'three';
import LabelMarker from '../shared/LabelMarker';
import ModelHud from '../shared/ModelHud';
import type { ModelViewProps } from '../../../types';

const R = 1.3;

export default function SphericalMirrors({ showLabels, selectedComponent, onSelectComponent }: ModelViewProps) {
  const [mirrorType, setMirrorType] = useState<'concave' | 'convex'>('concave');
  const isConcave = mirrorType === 'concave';
  const thetaMax = Math.PI / 2.3;

  const poleY = R;
  const centreY = isConcave ? 0 : 2 * R;
  const focusY = isConcave ? R / 2 : 1.5 * R;
  const objectY = -R * 0.6;
  const objectTipX = 0.55;
  const imageY = isConcave ? R * 0.3 : R * 1.15;
  const imageTipX = isConcave ? -0.3 : 0.22;

  const sel = (id: string) => selectedComponent === id;
  const pick = (id: string) => (e: any) => {
    e.stopPropagation();
    onSelectComponent(id);
  };

  return (
    <group>
      <ModelHud
        options={[
          { label: 'Concave', active: isConcave, onClick: () => setMirrorType('concave') },
          { label: 'Convex', active: !isConcave, onClick: () => setMirrorType('convex') },
        ]}
      />

      <mesh onClick={pick('pole')}>
        <sphereGeometry args={[R, 48, 32, 0, Math.PI * 2, 0, thetaMax]} />
        <meshStandardMaterial color="#B8C2D1" metalness={0.7} roughness={0.2} side={THREE.DoubleSide} />
      </mesh>

      <Line
        points={[
          [0, -R * 1.1, 0],
          [0, (isConcave ? R : 2 * R) + 0.5, 0],
        ]}
        color="#495363"
        lineWidth={1}
        dashed
        dashSize={0.08}
        gapSize={0.06}
      />

      <mesh position={[0, poleY, 0]} onClick={pick('pole')}>
        <sphereGeometry args={[0.045, 16, 16]} />
        <meshStandardMaterial color="#1E4D8C" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, poleY, 0.3]} label="Pole (P)" active={sel('pole')} onClick={() => onSelectComponent('pole')} />
      )}

      <mesh position={[0, centreY, 0]} onClick={pick('centre')}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="#A3650E" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, centreY, 0.3]} label="Centre (C)" active={sel('centre')} onClick={() => onSelectComponent('centre')} />
      )}

      <mesh position={[0, focusY, 0]} onClick={pick('focus')}>
        <sphereGeometry args={[0.045, 16, 16]} />
        <meshStandardMaterial color="#1F6E43" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, focusY, 0.3]} label="Focus (F)" active={sel('focus')} onClick={() => onSelectComponent('focus')} />
      )}

      {showLabels && (
        <LabelMarker
          position={[0, -R * 1.1, 0.3]}
          label="Principal Axis"
          active={sel('axis')}
          onClick={() => onSelectComponent('axis')}
        />
      )}

      <mesh position={[objectTipX / 2, objectY, 0]} rotation={[0, 0, -Math.PI / 2]} onClick={pick('object')}>
        <coneGeometry args={[0.07, objectTipX, 14]} />
        <meshStandardMaterial color="#1E4D8C" />
      </mesh>
      {showLabels && (
        <LabelMarker position={[objectTipX, objectY, 0]} label="Object" active={sel('object')} onClick={() => onSelectComponent('object')} />
      )}

      <mesh
        position={[imageTipX / 2, imageY, 0]}
        rotation={[0, 0, imageTipX > 0 ? -Math.PI / 2 : Math.PI / 2]}
        onClick={pick('image')}
      >
        <coneGeometry args={[0.055, Math.abs(imageTipX), 14]} />
        <meshStandardMaterial color="#A3650E" transparent opacity={isConcave ? 0.95 : 0.55} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[imageTipX, imageY, 0]} label="Image" active={sel('image')} onClick={() => onSelectComponent('image')} />
      )}

      <Line
        points={[
          [objectTipX, objectY, 0],
          [0, poleY, 0],
          [imageTipX, imageY, 0],
        ]}
        color="#D04343"
        lineWidth={1.5}
      />
      <Line
        points={[
          [objectTipX, objectY, 0],
          [0, focusY, 0],
          [0, (isConcave ? R : 2 * R) + 0.15, 0],
        ]}
        color="#2D7DD2"
        lineWidth={1.5}
      />
    </group>
  );
}
