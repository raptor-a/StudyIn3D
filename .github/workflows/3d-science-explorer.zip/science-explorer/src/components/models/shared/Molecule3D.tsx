import { useMemo } from 'react';
import * as THREE from 'three';
import LabelMarker from './LabelMarker';
import type { Pt3 } from '../../../utils/geometry';

export interface MoleculeAtom {
  id: string;
  /** Component id to report to onSelectComponent / compare against selectedComponent.
   *  Lets several atoms (e.g. four hydrogens) share one info-panel entry. Defaults to id. */
  group?: string;
  symbol: string;
  color: string;
  radius: number;
  position: Pt3;
}

export interface MoleculeBond {
  from: string;
  to: string;
  order?: 1 | 2 | 3;
}

interface BondProps {
  from: Pt3;
  to: Pt3;
  order: number;
  color?: string;
}

function Bond({ from, to, order, color = '#9CA3AF' }: BondProps) {
  const { mid, length, quaternion } = useMemo(() => {
    const a = new THREE.Vector3(from[0], from[1], from[2]);
    const b = new THREE.Vector3(to[0], to[1], to[2]);
    const mid = a.clone().add(b).multiplyScalar(0.5);
    const dir = b.clone().sub(a);
    const length = dir.length();
    const quaternion = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    return { mid: [mid.x, mid.y, mid.z] as Pt3, length, quaternion };
  }, [from, to]);

  const offsets = order === 2 ? [-0.065, 0.065] : order === 3 ? [-0.1, 0, 0.1] : [0];

  return (
    <group position={mid} quaternion={quaternion}>
      {offsets.map((off, i) => (
        <mesh key={i} position={[off, 0, 0]}>
          <cylinderGeometry args={[0.032, 0.032, length, 8]} />
          <meshStandardMaterial color={color} roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

interface Props {
  atoms: MoleculeAtom[];
  bonds: MoleculeBond[];
  viewMode: 'ball-stick' | 'space-filling';
  showLabels: boolean;
  selectedComponent: string | null;
  onSelectComponent: (id: string | null) => void;
}

export default function Molecule3D({ atoms, bonds, viewMode, showLabels, selectedComponent, onSelectComponent }: Props) {
  const atomMap = useMemo(() => new Map(atoms.map((a) => [a.id, a])), [atoms]);

  return (
    <group>
      {viewMode === 'ball-stick' &&
        bonds.map((bond, i) => {
          const a = atomMap.get(bond.from);
          const b = atomMap.get(bond.to);
          if (!a || !b) return null;
          return <Bond key={i} from={a.position} to={b.position} order={bond.order ?? 1} />;
        })}
      {atoms.map((atom) => {
        const scale = viewMode === 'space-filling' ? atom.radius * 1.9 : atom.radius;
        const componentId = atom.group ?? atom.id;
        const isActive = selectedComponent === componentId;
        return (
          <group key={atom.id}>
            <mesh
              position={atom.position}
              onClick={(e) => {
                e.stopPropagation();
                onSelectComponent(componentId);
              }}
            >
              <sphereGeometry args={[scale, 32, 32]} />
              <meshStandardMaterial
                color={atom.color}
                emissive={isActive ? atom.color : '#000000'}
                emissiveIntensity={isActive ? 0.45 : 0}
                roughness={0.35}
              />
            </mesh>
            {showLabels && (
              <LabelMarker
                position={[atom.position[0], atom.position[1] + scale + 0.28, atom.position[2]]}
                label={atom.symbol}
                active={isActive}
                onClick={() => onSelectComponent(componentId)}
              />
            )}
          </group>
        );
      })}
    </group>
  );
}
