import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import LabelMarker from './LabelMarker';
import { shellsFor } from '../../../data/elements';

interface ShellProps {
  radius: number;
  electronCount: number;
  shellIndex: number;
}

function ElectronShell({ radius, electronCount, shellIndex }: ShellProps) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.z += delta * (0.35 / (shellIndex + 1));
  });
  const tilt = shellIndex * 0.35;

  return (
    <group rotation={[tilt, 0, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[radius, 0.008, 8, 72]} />
        <meshBasicMaterial color="#9CA7B5" transparent opacity={0.55} />
      </mesh>
      <group ref={ref}>
        {Array.from({ length: electronCount }).map((_, i) => {
          const angle = (i / electronCount) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.cos(angle) * radius, 0, Math.sin(angle) * radius]}>
              <sphereGeometry args={[0.07, 12, 12]} />
              <meshStandardMaterial color="#1E4D8C" emissive="#1E4D8C" emissiveIntensity={0.55} />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}

interface Props {
  atomicNumber: number;
  symbol: string;
  showLabels: boolean;
}

export default function AtomModel({ atomicNumber, symbol, showLabels }: Props) {
  const shells = useMemo(() => shellsFor(atomicNumber), [atomicNumber]);

  return (
    <group>
      <mesh>
        <sphereGeometry args={[0.32, 24, 24]} />
        <meshStandardMaterial color="#A3650E" roughness={0.4} />
      </mesh>
      {showLabels && (
        <LabelMarker position={[0, 0.55, 0]} label={`${symbol} nucleus (Z=${atomicNumber})`} />
      )}
      {shells.map((count, i) => (
        <ElectronShell key={i} radius={0.95 + i * 0.75} electronCount={count} shellIndex={i} />
      ))}
    </group>
  );
}
