import { Html } from '@react-three/drei';
import type { Pt3 } from '../../../utils/geometry';

interface Props {
  position: Pt3;
  label: string;
  active?: boolean;
  visible?: boolean;
  onClick?: () => void;
}

export default function LabelMarker({ position, label, active = false, visible = true, onClick }: Props) {
  if (!visible) return null;
  return (
    <Html position={position} center distanceFactor={9} zIndexRange={[10, 0]}>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onClick?.();
        }}
        className={`whitespace-nowrap rounded-full border px-2.5 py-1 text-[11px] font-medium font-body shadow-sm transition-colors ${
          active
            ? 'border-ink bg-ink text-white'
            : 'border-line bg-white/95 text-ink-soft hover:border-ink hover:text-ink'
        }`}
      >
        {label}
      </button>
    </Html>
  );
}
