import { Html } from '@react-three/drei';

interface ToggleOption {
  label: string;
  active: boolean;
  onClick: () => void;
}

export default function ModelHud({ options }: { options: ToggleOption[] }) {
  return (
    <Html fullscreen>
      <div className="pointer-events-none h-full w-full">
        <div className="pointer-events-auto absolute left-3 top-3 flex flex-wrap gap-1.5">
          {options.map((opt) => (
            <button
              key={opt.label}
              type="button"
              onClick={opt.onClick}
              className={`rounded-full border px-2.5 py-1 font-body text-[11px] font-medium transition-colors ${
                opt.active
                  ? 'border-white bg-white text-ink'
                  : 'border-white/25 bg-black/40 text-white/75 hover:border-white/50'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>
    </Html>
  );
}
