import { useMemo } from 'react';
import * as THREE from 'three';
import type { Pt3 } from '../../../utils/geometry';

interface Props {
  points: Pt3[];
  radius?: number;
  color?: string;
  closed?: boolean;
  segments?: number;
  opacity?: number;
  onClick?: () => void;
}

export default function TubePath({
  points,
  radius = 0.06,
  color = '#cc3333',
  closed = false,
  segments = 64,
  opacity = 1,
  onClick,
}: Props) {
  const geometry = useMemo(() => {
    const vecs = points.map((p) => new THREE.Vector3(p[0], p[1], p[2]));
    const curve = new THREE.CatmullRomCurve3(vecs, closed, 'catmullrom', 0.5);
    return new THREE.TubeGeometry(curve, segments, radius, 8, closed);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(points), radius, closed, segments]);

  return (
    <mesh
      geometry={geometry}
      onClick={(e) => {
        e.stopPropagation();
        onClick?.();
      }}
    >
      <meshStandardMaterial color={color} roughness={0.45} transparent={opacity < 1} opacity={opacity} />
    </mesh>
  );
}
