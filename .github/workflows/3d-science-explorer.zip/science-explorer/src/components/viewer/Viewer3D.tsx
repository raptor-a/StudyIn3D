import { Suspense, useEffect, useRef, useState } from 'react';
import type { ComponentType } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { RotateCcw, RotateCw, Eye, EyeOff, Maximize2, Minimize2 } from 'lucide-react';
import ModelLoadingFallback from './ModelLoadingFallback';
import type { ModelViewProps } from '../../types';

interface Props {
  ModelComponent: ComponentType<ModelViewProps> | null;
  modelKey: string;
  showLabels: boolean;
  onToggleLabels: () => void;
  selectedComponent: string | null;
  onSelectComponent: (id: string | null) => void;
}

function ControlButton({
  onClick,
  active,
  label,
  children,
}: {
  onClick: () => void;
  active?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors ${
        active ? 'bg-white text-ink' : 'text-white/70 hover:bg-white/10 hover:text-white'
      }`}
    >
      {children}
    </button>
  );
}

export default function Viewer3D({
  ModelComponent,
  modelKey,
  showLabels,
  onToggleLabels,
  selectedComponent,
  onSelectComponent,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<any>(null);
  const [autoRotate, setAutoRotate] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  useEffect(() => {
    setAutoRotate(false);
  }, [modelKey]);

  function toggleFullscreen() {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  function resetView() {
    controlsRef.current?.reset?.();
  }

  return (
    <div ref={containerRef} className="relative h-full w-full bg-stage">
      {ModelComponent ? (
        <Canvas camera={{ position: [3.4, 2.3, 3.4], fov: 42 }} dpr={[1, 2]}>
          <color attach="background" args={['#0A0D12']} />
          <ambientLight intensity={0.65} />
          <directionalLight position={[5, 8, 5]} intensity={1} />
          <directionalLight position={[-6, -3, -4]} intensity={0.25} />
          <Suspense fallback={<ModelLoadingFallback />}>
            <ModelComponent
              key={modelKey}
              showLabels={showLabels}
              selectedComponent={selectedComponent}
              onSelectComponent={onSelectComponent}
            />
          </Suspense>
          <OrbitControls
            ref={controlsRef}
            autoRotate={autoRotate}
            autoRotateSpeed={1.1}
            enableDamping
            dampingFactor={0.08}
            minDistance={1.4}
            maxDistance={16}
          />
        </Canvas>
      ) : null}

      <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-0.5 rounded-full border border-white/10 bg-black/55 px-1.5 py-1 backdrop-blur-sm">
        <ControlButton onClick={resetView} label="Reset view">
          <RotateCcw size={15} />
        </ControlButton>
        <ControlButton onClick={() => setAutoRotate((v) => !v)} active={autoRotate} label="Toggle auto-rotate">
          <RotateCw size={15} />
        </ControlButton>
        <ControlButton onClick={onToggleLabels} active={showLabels} label="Toggle labels">
          {showLabels ? <Eye size={15} /> : <EyeOff size={15} />}
        </ControlButton>
        <ControlButton onClick={toggleFullscreen} active={isFullscreen} label="Toggle fullscreen">
          {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </ControlButton>
      </div>
    </div>
  );
}
