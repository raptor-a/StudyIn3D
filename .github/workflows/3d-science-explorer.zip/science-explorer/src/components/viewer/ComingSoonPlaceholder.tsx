import { Box } from 'lucide-react';

interface Props {
  title: string;
}

export default function ComingSoonPlaceholder({ title }: Props) {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-stage px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full border border-stage-line text-white/35">
        <Box size={22} strokeWidth={1.5} />
      </div>
      <p className="font-display text-base font-medium text-white/85">{title}</p>
      <p className="max-w-xs font-body text-sm text-white/40">
        An interactive 3D model for this topic isn\u2019t built yet — it\u2019s on the roadmap.
      </p>
    </div>
  );
}
