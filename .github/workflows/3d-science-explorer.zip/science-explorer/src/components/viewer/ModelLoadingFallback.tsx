import { Html } from '@react-three/drei';

export default function ModelLoadingFallback() {
  return (
    <Html center>
      <div className="flex items-center gap-2 whitespace-nowrap rounded-full border border-stage-line bg-black/60 px-3 py-1.5 font-body text-xs text-white/80">
        <span className="h-2 w-2 animate-pulse rounded-full bg-white/70" />
        Loading model…
      </div>
    </Html>
  );
}
