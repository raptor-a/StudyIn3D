import { useEffect, useState } from 'react';
import Sidebar from '../components/layout/Sidebar';
import TopBar from '../components/layout/TopBar';
import InfoPanel from '../components/layout/InfoPanel';
import Viewer3D from '../components/viewer/Viewer3D';
import ComingSoonPlaceholder from '../components/viewer/ComingSoonPlaceholder';
import { modelRegistry } from '../components/models/registry';
import { getModelById, getChapterById, modelsForChapter, subjectMeta } from '../data';
import { useRecentlyViewed } from '../hooks/useLocalStorage';
import type { Subject } from '../types';
import type { SearchResult } from '../data';

interface Props {
  initialSubject: Subject;
  initialChapterId: string;
  initialModelId: string | null;
  initialComingSoonTopic?: string;
  onGoHome: () => void;
}

export default function ExplorerPage({ initialSubject, initialChapterId, initialModelId, initialComingSoonTopic, onGoHome }: Props) {
  const [chapterId, setChapterId] = useState(initialChapterId);
  const [modelId, setModelId] = useState<string | null>(initialModelId);
  const [comingSoonLabel, setComingSoonLabel] = useState<string | null>(initialComingSoonTopic ?? null);
  const [showLabels, setShowLabels] = useState(true);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [infoExpanded, setInfoExpanded] = useState(false);
  const { record } = useRecentlyViewed();

  const chapter = getChapterById(chapterId) ?? null;
  const model = modelId ? getModelById(modelId) ?? null : null;
  const subject = chapter?.subject ?? initialSubject;

  useEffect(() => {
    if (model) record(model.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model?.id]);

  function selectChapter(id: string) {
    setChapterId(id);
    setComingSoonLabel(null);
    setSelectedComponent(null);
    const firstModel = modelsForChapter(id)[0];
    setModelId(firstModel ? firstModel.id : null);
    setMobileSidebarOpen(false);
    setInfoExpanded(false);
  }

  function selectModel(id: string) {
    const m = getModelById(id);
    if (!m) return;
    setChapterId(m.chapterId);
    setModelId(id);
    setComingSoonLabel(null);
    setSelectedComponent(null);
    setMobileSidebarOpen(false);
  }

  function selectComingSoon(chId: string, topic: string) {
    setChapterId(chId);
    setModelId(null);
    setComingSoonLabel(topic);
    setSelectedComponent(null);
    setMobileSidebarOpen(false);
  }

  function handleSearchSelect(result: SearchResult) {
    if (result.type === 'model' && result.modelId) {
      selectModel(result.modelId);
    } else {
      selectComingSoon(result.chapterId, result.title);
    }
  }

  const ModelComponent = modelId ? modelRegistry[modelId] ?? null : null;
  const breadcrumb = [subjectMeta[subject].title, chapter?.title, model?.title ?? comingSoonLabel ?? undefined].filter(Boolean) as string[];

  return (
    <div className="flex h-full flex-col">
      <TopBar
        onGoHome={onGoHome}
        onOpenMobileSidebar={() => setMobileSidebarOpen(true)}
        breadcrumb={breadcrumb}
        onSearchSelect={handleSearchSelect}
      />
      <div className="relative flex min-h-0 flex-1">
        <Sidebar
          activeSubject={subject}
          activeChapterId={chapterId}
          activeModelId={modelId}
          onSelectChapter={selectChapter}
          onSelectModel={selectModel}
          onSelectComingSoon={selectComingSoon}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />
        <main className="relative min-w-0 flex-1 pb-[58px] lg:pb-0">
          {ModelComponent ? (
            <Viewer3D
              ModelComponent={ModelComponent}
              modelKey={modelId ?? 'none'}
              showLabels={showLabels}
              onToggleLabels={() => setShowLabels((v) => !v)}
              selectedComponent={selectedComponent}
              onSelectComponent={setSelectedComponent}
            />
          ) : (
            <ComingSoonPlaceholder title={comingSoonLabel ?? chapter?.title ?? 'Pick a model'} />
          )}
        </main>
        <InfoPanel
          model={model}
          chapter={chapter}
          comingSoonLabel={comingSoonLabel}
          selectedComponent={selectedComponent}
          onSelectComponent={setSelectedComponent}
          expanded={infoExpanded}
          onToggleExpanded={() => setInfoExpanded((v) => !v)}
        />
      </div>
    </div>
  );
}
