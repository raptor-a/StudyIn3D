export type Subject = 'physics' | 'chemistry' | 'biology';

export interface ModelComponentInfo {
  id: string;
  name: string;
  description: string;
}

export interface ScienceModel {
  id: string;
  subject: Subject;
  chapterId: string;
  title: string;
  description: string;
  learningPoints: string[];
  components: ModelComponentInfo[];
  modelType: string;
  keywords: string[];
}

export interface Chapter {
  id: string;
  subject: Subject;
  title: string;
  blurb: string;
  modelIds: string[];
  comingSoonTopics: string[];
}

export interface ModelViewProps {
  showLabels: boolean;
  selectedComponent: string | null;
  onSelectComponent: (id: string | null) => void;
}
