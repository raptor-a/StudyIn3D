import type { ScienceModel, Chapter, Subject } from '../types';
import { chapters, subjectMeta } from './chapters';
import { physicsModels } from './models/physics';
import { chemistryModels } from './models/chemistry';
import { biologyModels } from './models/biology';

export { chapters, subjectMeta };

export const allModels: ScienceModel[] = [...physicsModels, ...chemistryModels, ...biologyModels];

const modelsById = new Map(allModels.map((m) => [m.id, m]));
const chaptersById = new Map(chapters.map((c) => [c.id, c]));

export function getModelById(id: string): ScienceModel | undefined {
  return modelsById.get(id);
}

export function getChapterById(id: string): Chapter | undefined {
  return chaptersById.get(id);
}

export function chaptersForSubject(subject: Subject): Chapter[] {
  return chapters.filter((c) => c.subject === subject);
}

export function modelsForChapter(chapterId: string): ScienceModel[] {
  const chapter = chaptersById.get(chapterId);
  if (!chapter) return [];
  return chapter.modelIds.map((id) => modelsById.get(id)).filter((m): m is ScienceModel => !!m);
}

export const totalChapterCount = chapters.length;
export const totalModelCount = allModels.length;
export const totalComingSoonCount = chapters.reduce((sum, c) => sum + c.comingSoonTopics.length, 0);

export interface SearchResult {
  type: 'model' | 'coming-soon';
  subject: Subject;
  chapterId: string;
  chapterTitle: string;
  title: string;
  modelId?: string;
}

export function searchAll(query: string): SearchResult[] {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return [];
  const results: SearchResult[] = [];

  for (const model of allModels) {
    const chapter = chaptersById.get(model.chapterId);
    const haystack = [model.title, model.description, ...model.keywords, chapter?.title ?? ''].join(' ').toLowerCase();
    if (haystack.includes(q)) {
      results.push({
        type: 'model',
        subject: model.subject,
        chapterId: model.chapterId,
        chapterTitle: chapter?.title ?? '',
        title: model.title,
        modelId: model.id,
      });
    }
  }

  for (const chapter of chapters) {
    for (const topic of chapter.comingSoonTopics) {
      if (topic.toLowerCase().includes(q)) {
        results.push({
          type: 'coming-soon',
          subject: chapter.subject,
          chapterId: chapter.id,
          chapterTitle: chapter.title,
          title: topic,
        });
      }
    }
  }

  return results.slice(0, 20);
}
