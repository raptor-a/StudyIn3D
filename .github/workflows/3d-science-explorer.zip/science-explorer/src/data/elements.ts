export interface ElementData {
  symbol: string;
  name: string;
  atomicNumber: number;
  period: number; // 1-4
  group: number; // 1-8, short-form table (matches NCERT scope: elements 1-20 only)
  category: 'metal' | 'nonmetal' | 'metalloid' | 'noble-gas';
  valency: number;
}

export const elements: ElementData[] = [
  { symbol: 'H', name: 'Hydrogen', atomicNumber: 1, period: 1, group: 1, category: 'nonmetal', valency: 1 },
  { symbol: 'He', name: 'Helium', atomicNumber: 2, period: 1, group: 8, category: 'noble-gas', valency: 0 },
  { symbol: 'Li', name: 'Lithium', atomicNumber: 3, period: 2, group: 1, category: 'metal', valency: 1 },
  { symbol: 'Be', name: 'Beryllium', atomicNumber: 4, period: 2, group: 2, category: 'metal', valency: 2 },
  { symbol: 'B', name: 'Boron', atomicNumber: 5, period: 2, group: 3, category: 'metalloid', valency: 3 },
  { symbol: 'C', name: 'Carbon', atomicNumber: 6, period: 2, group: 4, category: 'nonmetal', valency: 4 },
  { symbol: 'N', name: 'Nitrogen', atomicNumber: 7, period: 2, group: 5, category: 'nonmetal', valency: 3 },
  { symbol: 'O', name: 'Oxygen', atomicNumber: 8, period: 2, group: 6, category: 'nonmetal', valency: 2 },
  { symbol: 'F', name: 'Fluorine', atomicNumber: 9, period: 2, group: 7, category: 'nonmetal', valency: 1 },
  { symbol: 'Ne', name: 'Neon', atomicNumber: 10, period: 2, group: 8, category: 'noble-gas', valency: 0 },
  { symbol: 'Na', name: 'Sodium', atomicNumber: 11, period: 3, group: 1, category: 'metal', valency: 1 },
  { symbol: 'Mg', name: 'Magnesium', atomicNumber: 12, period: 3, group: 2, category: 'metal', valency: 2 },
  { symbol: 'Al', name: 'Aluminium', atomicNumber: 13, period: 3, group: 3, category: 'metal', valency: 3 },
  { symbol: 'Si', name: 'Silicon', atomicNumber: 14, period: 3, group: 4, category: 'metalloid', valency: 4 },
  { symbol: 'P', name: 'Phosphorus', atomicNumber: 15, period: 3, group: 5, category: 'nonmetal', valency: 3 },
  { symbol: 'S', name: 'Sulphur', atomicNumber: 16, period: 3, group: 6, category: 'nonmetal', valency: 2 },
  { symbol: 'Cl', name: 'Chlorine', atomicNumber: 17, period: 3, group: 7, category: 'nonmetal', valency: 1 },
  { symbol: 'Ar', name: 'Argon', atomicNumber: 18, period: 3, group: 8, category: 'noble-gas', valency: 0 },
  { symbol: 'K', name: 'Potassium', atomicNumber: 19, period: 4, group: 1, category: 'metal', valency: 1 },
  { symbol: 'Ca', name: 'Calcium', atomicNumber: 20, period: 4, group: 2, category: 'metal', valency: 2 },
];

export function shellsFor(atomicNumber: number): number[] {
  const caps = [2, 8, 8, 18];
  let remaining = atomicNumber;
  const shells: number[] = [];
  for (const cap of caps) {
    if (remaining <= 0) break;
    const fill = Math.min(cap, remaining);
    shells.push(fill);
    remaining -= fill;
  }
  return shells;
}
