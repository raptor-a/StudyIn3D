/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#14181F',
        'ink-soft': '#565F6E',
        paper: '#EEF0F3',
        line: '#D7DBE1',
        stage: '#0A0D12',
        'stage-line': '#232A35',
        physics: { DEFAULT: '#1E4D8C', soft: '#DCE6F4', deep: '#133766' },
        chemistry: { DEFAULT: '#A3650E', soft: '#F3E6D2', deep: '#7A4A09' },
        biology: { DEFAULT: '#1F6E43', soft: '#DCEEE2', deep: '#154E30' },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"IBM Plex Sans"', 'sans-serif'],
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '8px',
        lg: '14px',
      },
    },
  },
  plugins: [],
};
