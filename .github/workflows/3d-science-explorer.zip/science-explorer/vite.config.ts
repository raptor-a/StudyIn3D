import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // Deployed at https://raptor-a.github.io/StudyIn3D/ — GitHub Pages serves this
  // project from a /StudyIn3D/ subpath, so built asset URLs must be rooted there.
  // If you ever rename the repo, update this to match: '/<new-repo-name>/'.
  base: '/StudyIn3D/',
  plugins: [react()],
  server: {
    host: true,
  },
});
